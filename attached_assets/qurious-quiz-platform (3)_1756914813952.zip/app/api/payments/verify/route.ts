import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase/server"
import { cookies } from "next/headers"
import crypto from "crypto"

export async function POST(request: NextRequest) {
  try {
    const cookieStore = cookies()
    const supabase = createServerClient(cookieStore)

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, paymentId, planId, billingCycle } =
      await request.json()

    // Verify Razorpay signature
    const body = razorpay_order_id + "|" + razorpay_payment_id
    const expectedSignature = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET!)
      .update(body.toString())
      .digest("hex")

    if (expectedSignature !== razorpay_signature) {
      return NextResponse.json({ error: "Invalid signature" }, { status: 400 })
    }

    // Update payment record
    const { error: updateError } = await supabase
      .from("payments")
      .update({
        gateway_payment_id: razorpay_payment_id,
        status: "completed",
        gateway_response: {
          razorpay_order_id,
          razorpay_payment_id,
          razorpay_signature,
        },
      })
      .eq("id", paymentId)

    if (updateError) {
      return NextResponse.json({ error: "Failed to update payment" }, { status: 500 })
    }

    // Get plan details for subscription creation
    const { data: plan } = await supabase.from("subscription_plans").select("*").eq("id", planId).single()

    if (!plan) {
      return NextResponse.json({ error: "Plan not found" }, { status: 404 })
    }

    // Create subscription
    const expiresAt = new Date()
    if (billingCycle === "yearly") {
      expiresAt.setFullYear(expiresAt.getFullYear() + 1)
    } else {
      expiresAt.setMonth(expiresAt.getMonth() + 1)
    }

    const amount = billingCycle === "yearly" ? plan.price_yearly : plan.price_monthly

    const { data: subscription, error: subscriptionError } = await supabase
      .from("user_subscriptions")
      .insert({
        user_id: user.id,
        plan_id: planId,
        status: "active",
        billing_cycle: billingCycle,
        amount_paid: amount,
        expires_at: expiresAt.toISOString(),
      })
      .select()
      .single()

    if (subscriptionError) {
      return NextResponse.json({ error: "Failed to create subscription" }, { status: 500 })
    }

    // Update payment with subscription ID
    await supabase.from("payments").update({ subscription_id: subscription.id }).eq("id", paymentId)

    return NextResponse.json({
      success: true,
      subscriptionId: subscription.id,
    })
  } catch (error) {
    console.error("Error verifying payment:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
