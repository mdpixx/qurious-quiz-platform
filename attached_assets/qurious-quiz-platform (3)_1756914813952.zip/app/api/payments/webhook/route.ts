import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase/server"
import { cookies } from "next/headers"
import crypto from "crypto"

export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const signature = request.headers.get("x-razorpay-signature")

    if (!signature) {
      return NextResponse.json({ error: "Missing signature" }, { status: 400 })
    }

    // Verify webhook signature
    const expectedSignature = crypto
      .createHmac("sha256", process.env.RAZORPAY_WEBHOOK_SECRET!)
      .update(body)
      .digest("hex")

    if (expectedSignature !== signature) {
      return NextResponse.json({ error: "Invalid signature" }, { status: 400 })
    }

    const event = JSON.parse(body)
    const cookieStore = cookies()
    const supabase = createServerClient(cookieStore)

    // Handle different webhook events
    switch (event.event) {
      case "payment.captured":
        await handlePaymentCaptured(supabase, event.payload.payment.entity)
        break
      case "payment.failed":
        await handlePaymentFailed(supabase, event.payload.payment.entity)
        break
      case "subscription.cancelled":
        await handleSubscriptionCancelled(supabase, event.payload.subscription.entity)
        break
    }

    return NextResponse.json({ status: "ok" })
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 })
  }
}

async function handlePaymentCaptured(supabase: any, payment: any) {
  await supabase
    .from("payments")
    .update({
      status: "completed",
      gateway_response: payment,
    })
    .eq("gateway_payment_id", payment.id)
}

async function handlePaymentFailed(supabase: any, payment: any) {
  await supabase
    .from("payments")
    .update({
      status: "failed",
      failure_reason: payment.error_description,
      gateway_response: payment,
    })
    .eq("gateway_payment_id", payment.id)
}

async function handleSubscriptionCancelled(supabase: any, subscription: any) {
  // Handle subscription cancellation logic
  console.log("Subscription cancelled:", subscription)
}
