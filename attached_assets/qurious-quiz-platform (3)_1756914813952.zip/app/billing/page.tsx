"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useI18n } from "@/lib/i18n/context"
import { createClient } from "@/lib/supabase/client"
import type { User } from "@supabase/supabase-js"

interface Subscription {
  id: string
  plan_name: string
  status: string
  current_period_start: string
  current_period_end: string
  amount: number
  currency: string
}

interface Payment {
  id: string
  amount: number
  currency: string
  status: string
  created_at: string
  plan_name: string
}

export default function BillingPage() {
  const { t } = useI18n()
  const [user, setUser] = useState<User | null>(null)
  const [subscription, setSubscription] = useState<Subscription | null>(null)
  const [payments, setPayments] = useState<Payment[]>([])
  const [loading, setLoading] = useState(true)

  const supabase = createClient()

  useEffect(() => {
    loadBillingData()
  }, [])

  const loadBillingData = async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) return

      setUser(user)

      // Load current subscription
      const { data: subData } = await supabase
        .from("user_subscriptions")
        .select(`
          id,
          status,
          current_period_start,
          current_period_end,
          subscription_plans (
            name,
            price,
            currency
          )
        `)
        .eq("user_id", user.id)
        .eq("status", "active")
        .single()

      if (subData) {
        setSubscription({
          id: subData.id,
          plan_name: subData.subscription_plans?.name || "Unknown",
          status: subData.status,
          current_period_start: subData.current_period_start,
          current_period_end: subData.current_period_end,
          amount: subData.subscription_plans?.price || 0,
          currency: subData.subscription_plans?.currency || "INR",
        })
      }

      // Load payment history
      const { data: paymentData } = await supabase
        .from("payments")
        .select(`
          id,
          amount,
          currency,
          status,
          created_at,
          subscription_plans (
            name
          )
        `)
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(10)

      if (paymentData) {
        setPayments(
          paymentData.map((p) => ({
            id: p.id,
            amount: p.amount,
            currency: p.currency,
            status: p.status,
            created_at: p.created_at,
            plan_name: p.subscription_plans?.name || "Unknown",
          })),
        )
      }
    } catch (error) {
      console.error("Error loading billing data:", error)
    } finally {
      setLoading(false)
    }
  }

  const formatCurrency = (amount: number, currency: string) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: currency,
    }).format(amount)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-IN", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="h-32 bg-gray-200 rounded"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{t("billing.title")}</h1>
        <p className="text-gray-600">{t("billing.description")}</p>
      </div>

      {/* Current Subscription */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>{t("billing.currentPlan")}</CardTitle>
          <CardDescription>{t("billing.planDescription")}</CardDescription>
        </CardHeader>
        <CardContent>
          {subscription ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold">{subscription.plan_name}</h3>
                  <p className="text-gray-600">{formatCurrency(subscription.amount, subscription.currency)} / month</p>
                </div>
                <Badge variant={subscription.status === "active" ? "default" : "secondary"}>
                  {subscription.status}
                </Badge>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="font-medium text-gray-900">Billing Period</p>
                  <p className="text-gray-600">
                    {formatDate(subscription.current_period_start)} - {formatDate(subscription.current_period_end)}
                  </p>
                </div>
                <div>
                  <p className="font-medium text-gray-900">Next Payment</p>
                  <p className="text-gray-600">{formatDate(subscription.current_period_end)}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  Change Plan
                </Button>
                <Button variant="outline" size="sm">
                  Cancel Subscription
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-600 mb-4">No active subscription</p>
              <Button onClick={() => (window.location.href = "/pricing")}>Choose a Plan</Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Payment History */}
      <Card>
        <CardHeader>
          <CardTitle>{t("billing.paymentHistory")}</CardTitle>
          <CardDescription>Your recent payment transactions</CardDescription>
        </CardHeader>
        <CardContent>
          {payments.length > 0 ? (
            <div className="space-y-4">
              {payments.map((payment) => (
                <div key={payment.id} className="flex items-center justify-between py-3 border-b last:border-b-0">
                  <div>
                    <p className="font-medium">{payment.plan_name}</p>
                    <p className="text-sm text-gray-600">{formatDate(payment.created_at)}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">{formatCurrency(payment.amount, payment.currency)}</p>
                    <Badge variant={payment.status === "completed" ? "default" : "secondary"} className="text-xs">
                      {payment.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-600">No payment history available</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
