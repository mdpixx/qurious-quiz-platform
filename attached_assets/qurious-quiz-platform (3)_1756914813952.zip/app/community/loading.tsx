export default function Loading() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="space-y-8">
          {/* Header skeleton */}
          <div className="text-center space-y-4">
            <div className="h-12 bg-muted rounded-lg animate-pulse mx-auto max-w-md"></div>
            <div className="h-6 bg-muted rounded-lg animate-pulse mx-auto max-w-lg"></div>
          </div>

          {/* Search bar skeleton */}
          <div className="max-w-md mx-auto">
            <div className="h-12 bg-muted rounded-lg animate-pulse"></div>
          </div>

          {/* Filter tabs skeleton */}
          <div className="flex justify-center space-x-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-10 w-20 bg-muted rounded-lg animate-pulse"></div>
            ))}
          </div>

          {/* Quiz cards skeleton */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bg-card rounded-lg border p-6 space-y-4">
                <div className="h-6 bg-muted rounded animate-pulse"></div>
                <div className="h-4 bg-muted rounded animate-pulse w-3/4"></div>
                <div className="flex justify-between items-center">
                  <div className="h-4 bg-muted rounded animate-pulse w-1/3"></div>
                  <div className="h-4 bg-muted rounded animate-pulse w-1/4"></div>
                </div>
                <div className="h-10 bg-muted rounded animate-pulse"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
