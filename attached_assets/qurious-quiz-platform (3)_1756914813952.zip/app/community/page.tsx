import { createServerClient } from "@/lib/supabase/server"
import { cookies } from "next/headers"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Heart, Play, Users, Clock, Search, Filter, TrendingUp, Star } from "lucide-react"
import Link from "next/link"

export default async function CommunityPage() {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)

  // Get trending quizzes
  const { data: trendingQuizzes } = await supabase
    .from("quizzes")
    .select(`
      *,
      profiles:creator_id (
        id,
        full_name,
        avatar_url
      ),
      quiz_likes (count),
      quiz_sessions (count)
    `)
    .eq("is_public", true)
    .order("created_at", { ascending: false })
    .limit(12)

  // Get featured creators
  const { data: featuredCreators } = await supabase
    .from("profiles")
    .select(`
      *,
      quizzes:quizzes!creator_id (count),
      followers:follows!following_id (count)
    `)
    .order("created_at", { ascending: false })
    .limit(6)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">Discover Amazing Quizzes</h1>
          <p className="text-xl text-slate-600 mb-8">Explore thousands of quizzes created by our community</p>

          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4 max-w-2xl mx-auto">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
              <Input placeholder="Search quizzes, topics, or creators..." className="pl-10" />
            </div>
            <Button variant="outline" className="flex items-center gap-2 bg-transparent">
              <Filter className="h-4 w-4" />
              Filters
            </Button>
          </div>
        </div>

        {/* Categories */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Popular Categories</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {[
              { name: "Science", icon: "🔬", count: 234 },
              { name: "History", icon: "📚", count: 189 },
              { name: "Sports", icon: "⚽", count: 156 },
              { name: "Movies", icon: "🎬", count: 298 },
              { name: "Music", icon: "🎵", count: 167 },
              { name: "Geography", icon: "🌍", count: 145 },
            ].map((category) => (
              <Card key={category.name} className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl mb-2">{category.icon}</div>
                  <h3 className="font-semibold text-slate-900">{category.name}</h3>
                  <p className="text-sm text-slate-600">{category.count} quizzes</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Trending Quizzes */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <TrendingUp className="h-6 w-6 text-orange-500" />
              Trending Quizzes
            </h2>
            <Button variant="outline" asChild>
              <Link href="/community/trending">View All</Link>
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {trendingQuizzes?.map((quiz) => (
              <Card key={quiz.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg mb-2">{quiz.title}</CardTitle>
                      <p className="text-sm text-slate-600 mb-3">{quiz.description}</p>
                    </div>
                    <Button size="sm" variant="ghost" className="text-red-500">
                      <Heart className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="flex items-center gap-2 mb-3">
                    <Avatar className="h-6 w-6">
                      <AvatarImage src={quiz.profiles?.avatar_url || "/placeholder.svg"} />
                      <AvatarFallback>{quiz.profiles?.full_name?.charAt(0) || "U"}</AvatarFallback>
                    </Avatar>
                    <span className="text-sm text-slate-600">{quiz.profiles?.full_name || "Anonymous"}</span>
                  </div>

                  <div className="flex items-center gap-4 text-sm text-slate-500">
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      {quiz.quiz_sessions?.[0]?.count || 0} plays
                    </div>
                    <div className="flex items-center gap-1">
                      <Heart className="h-4 w-4" />
                      {quiz.quiz_likes?.[0]?.count || 0} likes
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {quiz.time_limit || 30}s
                    </div>
                  </div>
                </CardHeader>

                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="flex gap-2">
                      <Badge variant="secondary">{quiz.category}</Badge>
                      <Badge variant="outline">{quiz.difficulty}</Badge>
                    </div>
                    <Button asChild>
                      <Link href={`/quiz/${quiz.id}`}>
                        <Play className="h-4 w-4 mr-2" />
                        Play
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Featured Creators */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <Star className="h-6 w-6 text-yellow-500" />
              Featured Creators
            </h2>
            <Button variant="outline" asChild>
              <Link href="/community/creators">View All</Link>
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredCreators?.map((creator) => (
              <Card key={creator.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <Avatar className="h-16 w-16 mx-auto mb-4">
                    <AvatarImage src={creator.avatar_url || "/placeholder.svg"} />
                    <AvatarFallback className="text-lg">{creator.full_name?.charAt(0) || "U"}</AvatarFallback>
                  </Avatar>

                  <h3 className="font-semibold text-lg text-slate-900 mb-2">{creator.full_name || "Anonymous User"}</h3>

                  <div className="flex justify-center gap-4 text-sm text-slate-600 mb-4">
                    <div>
                      <span className="font-semibold text-slate-900">{creator.quizzes?.[0]?.count || 0}</span>
                      <br />
                      Quizzes
                    </div>
                    <div>
                      <span className="font-semibold text-slate-900">{creator.followers?.[0]?.count || 0}</span>
                      <br />
                      Followers
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1 bg-transparent" asChild>
                      <Link href={`/profile/${creator.id}`}>View Profile</Link>
                    </Button>
                    <Button size="sm" className="flex-1">
                      Follow
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
