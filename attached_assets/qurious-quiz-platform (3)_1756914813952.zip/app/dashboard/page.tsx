import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase/server"
import { cookies } from "next/headers"
import { Navigation } from "@/components/navigation"
import { DashboardClient } from "@/components/dashboard-client"

export default async function DashboardPage() {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()

  if (error || !user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  const { data: quizzes } = await supabase
    .from("quizzes")
    .select(`
      *,
      questions:questions(count)
    `)
    .eq("creator_id", user.id)
    .order("created_at", { ascending: false })

  // Transform quizzes to include question count
  const transformedQuizzes =
    quizzes?.map((quiz) => ({
      ...quiz,
      total_questions: quiz.questions?.[0]?.count || 0,
    })) || []

  const handleSignOut = async () => {
    "use server"
    const cookieStore = cookies()
    const supabase = createServerClient(cookieStore)
    await supabase.auth.signOut()
    redirect("/")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5">
      <Navigation
        userDisplayName={profile?.full_name || user.email?.split("@")[0] || "Quiz Master"}
        onSignOut={handleSignOut}
      />

      <div className="container mx-auto px-4 py-8">
        <DashboardClient
          quizzes={transformedQuizzes}
          profile={
            profile || {
              id: user.id,
              full_name: user.email?.split("@")[0] || "Quiz Master",
              total_points: 0,
              badges: [],
            }
          }
        />
      </div>
    </div>
  )
}
