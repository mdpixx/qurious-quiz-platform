"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { Play, Users, Trophy, Zap } from "lucide-react"
import { useI18n } from "@/lib/i18n/context"
import { LanguageSwitcher } from "@/components/language-switcher"

interface HomePageClientProps {
  user?: any
}

export function HomePageClient({ user }: HomePageClientProps) {
  const { t } = useI18n()

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5">
      {/* Header with language switcher */}
      <header className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Qurious
          </h1>
          <div className="flex items-center gap-4">
            <LanguageSwitcher />
            {user && (
              <Button asChild variant="outline" size="sm">
                <Link href="/dashboard">{t("dashboard")}</Link>
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <h1 className="text-6xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent mb-6">
            Qurious
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">{t("welcomeMessage")}</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {user ? (
              <>
                <Button asChild size="lg" className="text-lg px-8 py-6">
                  <Link href="/quiz/create">{t("createQuiz")}</Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="text-lg px-8 py-6 bg-transparent">
                  <Link href="/dashboard">{t("dashboard")}</Link>
                </Button>
              </>
            ) : (
              <>
                <Button asChild size="lg" className="text-lg px-8 py-6">
                  <Link href="/auth/signup">{t("getStarted")}</Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="text-lg px-8 py-6 bg-transparent">
                  <Link href="/auth/login">{t("signIn")}</Link>
                </Button>
              </>
            )}
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <Card className="border-2 hover:border-primary/50 transition-colors">
            <CardHeader className="text-center">
              <div className="mx-auto w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <Play className="w-6 h-6 text-primary" />
              </div>
              <CardTitle>{t("liveQuizzes")}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center">{t("liveQuizzesDesc")}</CardDescription>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-secondary/50 transition-colors">
            <CardHeader className="text-center">
              <div className="mx-auto w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-secondary" />
              </div>
              <CardTitle>{t("teamMode")}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center">{t("teamModeDesc")}</CardDescription>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-accent/50 transition-colors">
            <CardHeader className="text-center">
              <div className="mx-auto w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                <Trophy className="w-6 h-6 text-accent" />
              </div>
              <CardTitle>{t("achievements")}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center">{t("achievementsDesc")}</CardDescription>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-primary/50 transition-colors">
            <CardHeader className="text-center">
              <div className="mx-auto w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <CardTitle>{t("instantResults")}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center">{t("instantResultsDesc")}</CardDescription>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
