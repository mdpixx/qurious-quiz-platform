"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Users, Clock, UserPlus } from "lucide-react"

interface QuizSession {
  id: string
  session_code: string
  status: "waiting" | "active" | "paused" | "completed"
  quiz_id: string
  quizzes: {
    title: string
    description: string
    total_questions: number
  }
}

interface Participant {
  id: string
  nickname: string
  score: number
  created_at: string
}

const generateAnonymousName = () => {
  const adjectives = [
    "Smart",
    "Clever",
    "Quick",
    "Bright",
    "Sharp",
    "Wise",
    "Swift",
    "Bold",
    "Keen",
    "Alert",
    "Witty",
    "Savvy",
    "Agile",
    "Rapid",
    "Genius",
    "Brilliant",
  ]
  const animals = [
    "Fox",
    "Eagle",
    "Tiger",
    "Lion",
    "Wolf",
    "Hawk",
    "Owl",
    "Dolphin",
    "Cheetah",
    "Falcon",
    "Shark",
    "Panther",
    "Raven",
    "Lynx",
    "Jaguar",
    "Phoenix",
  ]

  const adjective = adjectives[Math.floor(Math.random() * adjectives.length)]
  const animal = animals[Math.floor(Math.random() * animals.length)]
  const number = Math.floor(Math.random() * 999) + 1

  return `${adjective}${animal}${number}`
}

export default function JoinQuizPage({ params }: { params: { code: string } }) {
  const router = useRouter()
  const [session, setSession] = useState<QuizSession | null>(null)
  const [nickname, setNickname] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isJoining, setIsJoining] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [participants, setParticipants] = useState<Participant[]>([])
  const [recentJoins, setRecentJoins] = useState<string[]>([])

  const supabase = createClient()

  useEffect(() => {
    loadSession()
    setNickname(generateAnonymousName())
  }, [params.code])

  useEffect(() => {
    if (!session) return

    const loadParticipants = async () => {
      const { data } = await supabase
        .from("participants")
        .select("*")
        .eq("session_id", session.id)
        .order("created_at", { ascending: true })

      if (data) setParticipants(data)
    }

    loadParticipants()

    // Subscribe to real-time changes
    const channel = supabase
      .channel(`participants-${session.id}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "participants",
          filter: `session_id=eq.${session.id}`,
        },
        (payload) => {
          const newParticipant = payload.new as Participant
          setParticipants((prev) => [...prev, newParticipant])

          // Show recent join animation
          setRecentJoins((prev) => [...prev, newParticipant.nickname])
          setTimeout(() => {
            setRecentJoins((prev) => prev.filter((name) => name !== newParticipant.nickname))
          }, 3000)
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [session])

  const loadSession = async () => {
    try {
      const { data, error } = await supabase
        .from("quiz_sessions")
        .select(`
          *,
          quizzes (title, description, total_questions)
        `)
        .eq("session_code", params.code)
        .single()

      if (error) throw new Error("Session not found")

      if (data.status === "completed") {
        throw new Error("This quiz session has ended")
      }

      setSession(data)
    } catch (error: any) {
      setError(error.message)
    } finally {
      setIsLoading(false)
    }
  }

  const joinSession = async () => {
    if (!session || !nickname.trim()) return

    setIsJoining(true)
    setError(null)

    try {
      // Check if nickname is already taken in this session
      const { data: existingParticipant } = await supabase
        .from("participants")
        .select("id")
        .eq("session_id", session.id)
        .eq("nickname", nickname.trim())
        .single()

      if (existingParticipant) {
        throw new Error("This nickname is already taken")
      }

      const { data: participant, error } = await supabase
        .from("participants")
        .insert({
          session_id: session.id,
          user_id: null, // Anonymous participation
          nickname: nickname.trim(),
          score: 0,
        })
        .select()
        .single()

      if (error) throw error

      // Redirect to the live quiz page
      router.push(`/play/${session.id}/${participant.id}`)
    } catch (error: any) {
      setError(error.message)
    } finally {
      setIsJoining(false)
    }
  }

  const generateNewName = () => {
    setNickname(generateAnonymousName())
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading session...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 via-background to-secondary/5 p-4">
        <Card className="max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-destructive">Session Not Found</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p>{error}</p>
            <Button asChild>
              <Link href="/">Go Home</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Join Card */}
        <div className="lg:col-span-2">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Qurious
            </h1>
            <p className="text-muted-foreground mt-2">Join the quiz session</p>
          </div>

          <Card className="border-2 shadow-xl">
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <span className="text-2xl font-bold text-primary">{params.code}</span>
              </div>
              <CardTitle className="text-2xl">{session?.quizzes.title}</CardTitle>
              <CardDescription>{session?.quizzes.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Quiz Info */}
              <div className="grid grid-cols-2 gap-4 text-center">
                <div className="p-3 bg-muted rounded-lg">
                  <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground mb-1">
                    <Users className="w-4 h-4" />
                    Questions
                  </div>
                  <div className="font-bold">{session?.quizzes.total_questions}</div>
                </div>
                <div className="p-3 bg-muted rounded-lg">
                  <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground mb-1">
                    <Clock className="w-4 h-4" />
                    Status
                  </div>
                  <Badge variant={session?.status === "waiting" ? "secondary" : "default"}>{session?.status}</Badge>
                </div>
              </div>

              {/* Join Form */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="nickname">Your Nickname</Label>
                  <div className="flex gap-2">
                    <Input
                      id="nickname"
                      placeholder="Enter your nickname"
                      value={nickname}
                      onChange={(e) => setNickname(e.target.value)}
                      maxLength={20}
                      onKeyPress={(e) => e.key === "Enter" && joinSession()}
                      className="flex-1"
                    />
                    <Button type="button" variant="outline" onClick={generateNewName} className="px-3 bg-transparent">
                      🎲
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">Click the dice to generate a new random name</p>
                </div>

                {error && (
                  <div className="p-3 text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-lg">
                    {error}
                  </div>
                )}

                <Button
                  onClick={joinSession}
                  disabled={!nickname.trim() || isJoining || session?.status === "active"}
                  className="w-full h-12 text-lg font-semibold"
                >
                  {isJoining ? "Joining..." : session?.status === "active" ? "Quiz in Progress" : "Join Quiz"}
                </Button>
              </div>

              {session?.status === "active" && (
                <div className="text-center text-sm text-muted-foreground">
                  This quiz is already in progress. Wait for the next session.
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-1">
          <Card className="h-fit">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Users className="w-5 h-5" />
                Players ({participants.length})
              </CardTitle>
              <CardDescription>Waiting to start...</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {participants.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">
                    <Users className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">No players yet</p>
                    <p className="text-xs">Be the first to join!</p>
                  </div>
                ) : (
                  participants.map((participant, index) => (
                    <div
                      key={participant.id}
                      className={`flex items-center gap-3 p-2 rounded-lg transition-all duration-300 ${
                        recentJoins.includes(participant.nickname)
                          ? "bg-green-100 border-2 border-green-300 animate-pulse"
                          : "bg-muted"
                      }`}
                    >
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-bold">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-sm">{participant.nickname}</p>
                        {recentJoins.includes(participant.nickname) && (
                          <div className="flex items-center gap-1 text-xs text-green-600">
                            <UserPlus className="w-3 h-3" />
                            Just joined!
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
