"use client"

import { useState, useEffect } from "react"
import { supabaseClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"
import { Trophy, Medal, Crown, Zap, Users, ArrowLeft } from "lucide-react"

interface LeaderboardUser {
  id: string
  username: string
  display_name: string
  avatar_url: string | null
  total_points: number
  badges: any[]
  quiz_count?: number
  avg_score?: number
  best_streak?: number
}

interface QuizLeaderboard {
  quiz_id: string
  quiz_title: string
  participant_count: number
  top_participants: {
    nickname: string
    score: number
    user_id: string | null
    profiles?: {
      username: string
      display_name: string
      avatar_url: string | null
    }
  }[]
}

export default function LeaderboardsPage() {
  const [globalLeaderboard, setGlobalLeaderboard] = useState<LeaderboardUser[]>([])
  const [weeklyLeaderboard, setWeeklyLeaderboard] = useState<LeaderboardUser[]>([])
  const [quizLeaderboards, setQuizLeaderboards] = useState<QuizLeaderboard[]>([])
  const [currentUser, setCurrentUser] = useState<LeaderboardUser | null>(null)
  const [userRank, setUserRank] = useState<number>(0)
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("global")

  const supabase = supabaseClient

  useEffect(() => {
    loadLeaderboards()
  }, [])

  const loadLeaderboards = async () => {
    try {
      console.log("[v0] Loading leaderboards...")

      const {
        data: { user },
        error: authError,
      } = await supabase.auth.getUser()

      if (authError) {
        console.log("[v0] Auth error:", authError)
      }

      // Load global leaderboard (all-time)
      const { data: globalData, error: globalError } = await supabase
        .from("profiles")
        .select("*")
        .order("total_points", { ascending: false })
        .limit(50)

      if (globalError) {
        console.log("[v0] Global leaderboard error:", globalError)
        throw globalError
      }

      console.log("[v0] Global leaderboard loaded:", globalData?.length || 0, "users")
      setGlobalLeaderboard(globalData || [])

      // Find current user rank
      if (user) {
        const { data: currentUserData } = await supabase.from("profiles").select("*").eq("id", user.id).single()

        if (currentUserData) {
          setCurrentUser(currentUserData)
          const rank = globalData.findIndex((u) => u.id === user.id) + 1
          setUserRank(rank)
        }
      }

      // Load weekly leaderboard (points earned in last 7 days)
      const weekAgo = new Date()
      weekAgo.setDate(weekAgo.getDate() - 7)

      const { data: weeklyData, error: weeklyError } = await supabase.rpc("get_weekly_leaderboard", {
        since_date: weekAgo.toISOString(),
      })

      if (!weeklyError && weeklyData) {
        setWeeklyLeaderboard(weeklyData)
      }

      // Load top quiz leaderboards
      const { data: quizData, error: quizError } = await supabase
        .from("quizzes")
        .select(`
          id,
          title,
          total_plays
        `)
        .eq("is_public", true)
        .order("total_plays", { ascending: false })
        .limit(10)

      if (quizError) {
        console.log("[v0] Quiz leaderboards error:", quizError)
        throw quizError
      }

      console.log("[v0] Quiz leaderboards loaded:", quizData?.length || 0, "quizzes")
      // Get top participants for each quiz
      const quizLeaderboardsData = await Promise.all(
        quizData.map(async (quiz) => {
          const { data: participants } = await supabase
            .from("participants")
            .select(`
              nickname,
              score,
              user_id,
              profiles:user_id (username, display_name, avatar_url),
              quiz_sessions!inner (quiz_id)
            `)
            .eq("quiz_sessions.quiz_id", quiz.id)
            .order("score", { ascending: false })
            .limit(5)

          return {
            quiz_id: quiz.id,
            quiz_title: quiz.title,
            participant_count: quiz.total_plays,
            top_participants: participants || [],
          }
        }),
      )

      setQuizLeaderboards(quizLeaderboardsData)
    } catch (error: any) {
      console.error("Error loading leaderboards:", error.message || error)
    } finally {
      setIsLoading(false)
    }
  }

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="w-6 h-6 text-yellow-500" />
      case 2:
        return <Trophy className="w-6 h-6 text-gray-400" />
      case 3:
        return <Medal className="w-6 h-6 text-amber-600" />
      default:
        return (
          <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center text-sm font-bold">{rank}</div>
        )
    }
  }

  const getRankBadge = (rank: number) => {
    switch (rank) {
      case 1:
        return <Badge className="bg-yellow-500 hover:bg-yellow-600">Champion</Badge>
      case 2:
        return <Badge className="bg-gray-400 hover:bg-gray-500">Runner-up</Badge>
      case 3:
        return <Badge className="bg-amber-600 hover:bg-amber-700">Third Place</Badge>
      default:
        return <Badge variant="outline">#{rank}</Badge>
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading leaderboards...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button asChild variant="ghost" size="sm">
                <Link href="/dashboard">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Link>
              </Button>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Leaderboards
              </h1>
            </div>
            {currentUser && userRank > 0 && (
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="text-sm text-muted-foreground">Your Rank</div>
                  <div className="font-bold">#{userRank}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-muted-foreground">Points</div>
                  <div className="font-bold">{currentUser.total_points}</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="global">Global Rankings</TabsTrigger>
              <TabsTrigger value="weekly">This Week</TabsTrigger>
              <TabsTrigger value="quizzes">Top Quizzes</TabsTrigger>
            </TabsList>

            <TabsContent value="global" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Trophy className="w-5 h-5" />
                    Global Leaderboard
                  </CardTitle>
                  <CardDescription>Top performers across all quizzes</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {globalLeaderboard.slice(0, 3).map((user, index) => (
                      <div
                        key={user.id}
                        className={`p-6 rounded-lg border-2 ${
                          index === 0
                            ? "border-yellow-500 bg-yellow-500/5"
                            : index === 1
                              ? "border-gray-400 bg-gray-400/5"
                              : "border-amber-600 bg-amber-600/5"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            {getRankIcon(index + 1)}
                            <Avatar className="w-12 h-12">
                              <AvatarImage src={user.avatar_url || ""} />
                              <AvatarFallback>{user.display_name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-bold text-lg">{user.display_name}</div>
                              <div className="text-sm text-muted-foreground">@{user.username}</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-2xl font-bold">{user.total_points}</div>
                            <div className="text-sm text-muted-foreground">points</div>
                          </div>
                        </div>
                      </div>
                    ))}

                    <div className="space-y-2">
                      {globalLeaderboard.slice(3).map((user, index) => (
                        <div
                          key={user.id}
                          className={`flex items-center justify-between p-4 rounded-lg ${
                            user.id === currentUser?.id ? "bg-primary/10 border border-primary" : "bg-muted"
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-background flex items-center justify-center text-sm font-bold">
                              {index + 4}
                            </div>
                            <Avatar className="w-8 h-8">
                              <AvatarImage src={user.avatar_url || ""} />
                              <AvatarFallback className="text-xs">{user.display_name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{user.display_name}</div>
                              <div className="text-xs text-muted-foreground">@{user.username}</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold">{user.total_points}</div>
                            <div className="text-xs text-muted-foreground">points</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="weekly" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="w-5 h-5" />
                    Weekly Champions
                  </CardTitle>
                  <CardDescription>Top performers this week</CardDescription>
                </CardHeader>
                <CardContent>
                  {weeklyLeaderboard.length > 0 ? (
                    <div className="space-y-3">
                      {weeklyLeaderboard.map((user, index) => (
                        <div
                          key={user.id}
                          className={`flex items-center justify-between p-4 rounded-lg ${
                            index < 3
                              ? index === 0
                                ? "bg-yellow-500/10 border border-yellow-500"
                                : index === 1
                                  ? "bg-gray-400/10 border border-gray-400"
                                  : "bg-amber-600/10 border border-amber-600"
                              : "bg-muted"
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            {getRankIcon(index + 1)}
                            <Avatar className="w-10 h-10">
                              <AvatarImage src={user.avatar_url || ""} />
                              <AvatarFallback>{user.display_name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{user.display_name}</div>
                              <div className="text-sm text-muted-foreground">@{user.username}</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold">{user.total_points}</div>
                            <div className="text-xs text-muted-foreground">points this week</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Zap className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-semibold mb-2">No activity this week</h3>
                      <p className="text-muted-foreground">Be the first to earn points this week!</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="quizzes" className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                {quizLeaderboards.map((quiz) => (
                  <Card key={quiz.quiz_id}>
                    <CardHeader>
                      <CardTitle className="text-lg">{quiz.quiz_title}</CardTitle>
                      <CardDescription>
                        <Users className="w-4 h-4 inline mr-1" />
                        {quiz.participant_count} total plays
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {quiz.top_participants.slice(0, 5).map((participant, index) => (
                          <div key={index} className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center text-xs font-bold">
                                {index + 1}
                              </div>
                              <div>
                                <div className="font-medium text-sm">
                                  {participant.profiles?.display_name || participant.nickname}
                                </div>
                                {participant.profiles?.username && (
                                  <div className="text-xs text-muted-foreground">@{participant.profiles.username}</div>
                                )}
                              </div>
                            </div>
                            <div className="font-bold text-sm">{participant.score}</div>
                          </div>
                        ))}
                        {quiz.top_participants.length === 0 && (
                          <div className="text-center py-4 text-sm text-muted-foreground">No participants yet</div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
