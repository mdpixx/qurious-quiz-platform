import { createServerClient } from "@/lib/supabase/server"
import { cookies } from "next/headers"
import { HomePageClient } from "./home-client"

export default async function HomePage() {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const {
    data: { user },
  } = await supabase.auth.getUser()

  // Now both authenticated and unauthenticated users can view the landing page
  return <HomePageClient user={user} />
}
