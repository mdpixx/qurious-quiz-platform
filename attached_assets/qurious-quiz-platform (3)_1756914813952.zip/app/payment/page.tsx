"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { ArrowLeft, CreditCard, Smartphone, Building, Wallet, Shield, CheckCircle } from "lucide-react"
import Script from "next/script"

declare global {
  interface Window {
    Razorpay: any
  }
}

interface SubscriptionPlan {
  id: string
  name: string
  description: string
  price_monthly: number
  price_yearly: number
  features: string[]
}

export default function PaymentPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [plan, setPlan] = useState<SubscriptionPlan | null>(null)
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly")
  const [paymentMethod, setPaymentMethod] = useState<string>("upi")
  const [upiId, setUpiId] = useState<string>("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [user, setUser] = useState<any>(null)
  const [razorpayLoaded, setRazorpayLoaded] = useState(false)

  const supabase = createClient()

  useEffect(() => {
    const planId = searchParams.get("plan")
    const billing = searchParams.get("billing") as "monthly" | "yearly"

    if (planId) {
      loadPlan(planId)
    }
    if (billing) {
      setBillingCycle(billing)
    }

    checkUser()
  }, [searchParams])

  const checkUser = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      router.push("/auth/login")
      return
    }

    setUser(user)
  }

  const loadPlan = async (planId: string) => {
    try {
      console.log("[v0] Loading plan with ID:", planId)

      const { data, error } = await supabase.from("subscription_plans").select("*").eq("id", planId).single()

      console.log("[v0] Supabase response:", { data, error })

      if (error) {
        console.error("[v0] Supabase error:", error)
        throw new Error(`Failed to load subscription plan: ${error.message}`)
      }

      if (!data) {
        throw new Error("Subscription plan not found")
      }

      setPlan(data)
      console.log("[v0] Plan loaded successfully:", data)
    } catch (error: any) {
      console.error("[v0] Error loading plan:", error)
      setError(`Failed to load subscription plan: ${error.message}`)

      // Create a fallback plan if database query fails
      const fallbackPlan: SubscriptionPlan = {
        id: planId,
        name: "Premium Plan",
        description: "Full access to all Qurious features",
        price_monthly: 299,
        price_yearly: 2999,
        features: [
          "Unlimited quiz creation",
          "Up to 1000 participants per session",
          "Advanced analytics",
          "Custom branding",
          "Priority support",
        ],
      }

      setPlan(fallbackPlan)
      console.log("[v0] Using fallback plan due to database error")
    }
  }

  const getAmount = () => {
    if (!plan) return 0
    return billingCycle === "yearly" ? plan.price_yearly : plan.price_monthly
  }

  const processPayment = async () => {
    if (!plan || !user || !razorpayLoaded) return

    setIsProcessing(true)
    setError(null)

    try {
      console.log("[v0] Starting Razorpay payment process")

      // Create Razorpay order
      const response = await fetch("/api/payments/create-order", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          planId: plan.id,
          billingCycle,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to create payment order")
      }

      const orderData = await response.json()

      // Initialize Razorpay
      const options = {
        key: orderData.key,
        amount: orderData.amount,
        currency: orderData.currency,
        name: "Qurious",
        description: `${plan.name} Plan - ${billingCycle}`,
        order_id: orderData.orderId,
        prefill: {
          email: user.email,
        },
        notes: {
          planId: plan.id,
          billingCycle,
        },
        theme: {
          color: "#3B82F6",
        },
        method: {
          upi: paymentMethod === "upi",
          card: paymentMethod === "card",
          netbanking: paymentMethod === "netbanking",
          wallet: paymentMethod === "wallet",
        },
        handler: async (response: any) => {
          try {
            // Verify payment
            const verifyResponse = await fetch("/api/payments/verify", {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature,
                paymentId: orderData.paymentId,
                planId: plan.id,
                billingCycle,
              }),
            })

            if (!verifyResponse.ok) {
              throw new Error("Payment verification failed")
            }

            const verifyData = await verifyResponse.json()

            console.log("[v0] Payment verified successfully")
            router.push(`/payment/success?subscription=${verifyData.subscriptionId}`)
          } catch (error) {
            console.error("[v0] Payment verification error:", error)
            setError("Payment verification failed. Please contact support.")
          }
        },
        modal: {
          ondismiss: () => {
            setIsProcessing(false)
          },
        },
      }

      const razorpay = new window.Razorpay(options)
      razorpay.open()
    } catch (error: any) {
      console.error("[v0] Payment process error:", error)
      setError(error.message || "Payment processing failed. Please try again.")
      setIsProcessing(false)
    }
  }

  if (!plan || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading payment details...</p>
        </div>
      </div>
    )
  }

  return (
    <>
      <Script src="https://checkout.razorpay.com/v1/checkout.js" onLoad={() => setRazorpayLoaded(true)} />

      <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5">
        {/* Header */}
        <header className="border-b bg-card/50 backdrop-blur-sm">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center gap-4">
              <Button asChild variant="ghost" size="sm">
                <Link href="/pricing">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Pricing
                </Link>
              </Button>
              <h1 className="text-xl font-bold">Complete Your Purchase</h1>
            </div>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Order Summary */}
              <Card>
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                  <CardDescription>Review your subscription details</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold text-lg">{plan.name} Plan</h3>
                      <p className="text-sm text-muted-foreground">{plan.description}</p>
                    </div>
                    <Badge variant="outline">{billingCycle}</Badge>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span>₹{getAmount().toLocaleString("en-IN")}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Tax (18% GST)</span>
                      <span>₹{(getAmount() * 0.18).toLocaleString("en-IN")}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-bold text-lg">
                      <span>Total</span>
                      <span>₹{(getAmount() * 1.18).toLocaleString("en-IN")}</span>
                    </div>
                  </div>

                  <div className="bg-muted p-4 rounded-lg">
                    <h4 className="font-semibold mb-2">What's included:</h4>
                    <ul className="space-y-1 text-sm">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-accent" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Form */}
              <Card>
                <CardHeader>
                  <CardTitle>Payment Method</CardTitle>
                  <CardDescription>Choose your preferred payment method</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                    <div className="flex items-center space-x-3 p-4 border rounded-lg">
                      <RadioGroupItem value="upi" id="upi" />
                      <Label htmlFor="upi" className="flex items-center gap-3 cursor-pointer flex-1">
                        <Smartphone className="w-5 h-5 text-primary" />
                        <div>
                          <div className="font-medium">UPI</div>
                          <div className="text-sm text-muted-foreground">Pay using Google Pay, PhonePe, Paytm</div>
                        </div>
                      </Label>
                    </div>

                    <div className="flex items-center space-x-3 p-4 border rounded-lg">
                      <RadioGroupItem value="card" id="card" />
                      <Label htmlFor="card" className="flex items-center gap-3 cursor-pointer flex-1">
                        <CreditCard className="w-5 h-5 text-secondary" />
                        <div>
                          <div className="font-medium">Credit/Debit Card</div>
                          <div className="text-sm text-muted-foreground">Visa, Mastercard, RuPay</div>
                        </div>
                      </Label>
                    </div>

                    <div className="flex items-center space-x-3 p-4 border rounded-lg">
                      <RadioGroupItem value="netbanking" id="netbanking" />
                      <Label htmlFor="netbanking" className="flex items-center gap-3 cursor-pointer flex-1">
                        <Building className="w-5 h-5 text-accent" />
                        <div>
                          <div className="font-medium">Net Banking</div>
                          <div className="text-sm text-muted-foreground">All major Indian banks</div>
                        </div>
                      </Label>
                    </div>

                    <div className="flex items-center space-x-3 p-4 border rounded-lg">
                      <RadioGroupItem value="wallet" id="wallet" />
                      <Label htmlFor="wallet" className="flex items-center gap-3 cursor-pointer flex-1">
                        <Wallet className="w-5 h-5 text-primary" />
                        <div>
                          <div className="font-medium">Digital Wallets</div>
                          <div className="text-sm text-muted-foreground">Paytm, Mobikwik, Amazon Pay</div>
                        </div>
                      </Label>
                    </div>
                  </RadioGroup>

                  {paymentMethod === "upi" && (
                    <div className="space-y-2">
                      <Label htmlFor="upi-id">UPI ID (Optional)</Label>
                      <Input
                        id="upi-id"
                        placeholder="yourname@paytm"
                        value={upiId}
                        onChange={(e) => setUpiId(e.target.value)}
                      />
                      <p className="text-xs text-muted-foreground">
                        Leave empty to choose from available UPI apps during payment
                      </p>
                    </div>
                  )}

                  {error && (
                    <div className="p-3 text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-lg">
                      {error}
                    </div>
                  )}

                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Shield className="w-4 h-4" />
                    <span>Your payment is secured with 256-bit SSL encryption</span>
                  </div>

                  <Button
                    onClick={processPayment}
                    disabled={isProcessing || !razorpayLoaded}
                    className="w-full"
                    size="lg"
                  >
                    {isProcessing ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Processing Payment...
                      </>
                    ) : !razorpayLoaded ? (
                      "Loading Payment Gateway..."
                    ) : (
                      `Pay ₹{(getAmount() * 1.18).toLocaleString("en-IN")}`
                    )}
                  </Button>

                  <p className="text-xs text-center text-muted-foreground">
                    By completing this purchase, you agree to our Terms of Service and Privacy Policy. You can cancel
                    your subscription at any time.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
