"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { CheckCircle, Download, CreditCard } from "lucide-react"

interface Subscription {
  id: string
  status: string
  billing_cycle: string
  amount_paid: number
  started_at: string
  expires_at: string
  subscription_plans: {
    name: string
    description: string
    features: string[]
  }
}

export default function PaymentSuccessPage() {
  const searchParams = useSearchParams()
  const [subscription, setSubscription] = useState<Subscription | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  const supabase = createClient()

  useEffect(() => {
    const subscriptionId = searchParams.get("subscription")
    if (subscriptionId) {
      loadSubscription(subscriptionId)
    }
  }, [searchParams])

  const loadSubscription = async (subscriptionId: string) => {
    try {
      const { data, error } = await supabase
        .from("user_subscriptions")
        .select(`
          *,
          subscription_plans (name, description, features)
        `)
        .eq("id", subscriptionId)
        .single()

      if (error) throw error
      setSubscription(data)
    } catch (error) {
      console.error("Error loading subscription:", error)
    } finally {
      setIsLoading(false)
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading subscription details...</p>
        </div>
      </div>
    )
  }

  if (!subscription) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 via-background to-secondary/5 p-4">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="text-destructive">Subscription Not Found</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">We couldn't find your subscription details.</p>
            <Button asChild>
              <Link href="/dashboard">Go to Dashboard</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        <Card className="border-2 border-accent shadow-xl">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mb-4">
              <CheckCircle className="w-8 h-8 text-accent" />
            </div>
            <CardTitle className="text-3xl text-accent">Payment Successful!</CardTitle>
            <CardDescription className="text-lg">
              Welcome to {subscription.subscription_plans.name}! Your subscription is now active.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-8">
            {/* Subscription Details */}
            <div className="bg-muted p-6 rounded-lg space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-lg">{subscription.subscription_plans.name} Plan</h3>
                <Badge className="bg-accent">{subscription.status}</Badge>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground">Amount Paid</div>
                  <div className="font-semibold">₹{subscription.amount_paid.toLocaleString("en-IN")}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Billing Cycle</div>
                  <div className="font-semibold capitalize">{subscription.billing_cycle}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Started</div>
                  <div className="font-semibold">{new Date(subscription.started_at).toLocaleDateString("en-IN")}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Expires</div>
                  <div className="font-semibold">{new Date(subscription.expires_at).toLocaleDateString("en-IN")}</div>
                </div>
              </div>
            </div>

            {/* Features */}
            <div>
              <h4 className="font-semibold mb-4">What's included in your plan:</h4>
              <div className="grid gap-3">
                {subscription.subscription_plans.features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-accent flex-shrink-0" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Next Steps */}
            <div className="bg-primary/5 p-6 rounded-lg">
              <h4 className="font-semibold mb-4">What's next?</h4>
              <div className="space-y-3 text-sm">
                <div className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">
                    1
                  </div>
                  <span>Start creating unlimited quizzes with advanced features</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">
                    2
                  </div>
                  <span>Access advanced analytics and custom branding options</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">
                    3
                  </div>
                  <span>Get priority support for any questions or issues</span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild className="flex-1">
                <Link href="/dashboard">
                  <CreditCard className="w-4 h-4 mr-2" />
                  Go to Dashboard
                </Link>
              </Button>
              <Button asChild variant="outline" className="flex-1 bg-transparent">
                <Link href="/billing">
                  <Download className="w-4 h-4 mr-2" />
                  Download Invoice
                </Link>
              </Button>
            </div>

            {/* Support */}
            <div className="text-center text-sm text-muted-foreground">
              <p>
                Need help getting started?{" "}
                <Link href="/support" className="text-primary hover:underline">
                  Contact our support team
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
