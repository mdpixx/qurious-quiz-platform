"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, XCircle, Clock } from "lucide-react"

interface QuizSession {
  id: string
  status: "waiting" | "active" | "paused" | "completed"
  current_question_index: number
  quizzes: {
    title: string
    total_questions: number
  }
}

interface Question {
  id: string
  question_text: string
  question_type: string
  options: string[]
  points: number
  time_limit: number
}

interface Participant {
  id: string
  nickname: string
  score: number
  current_streak: number
}

export default function PlayQuizPage({
  params,
}: {
  params: { sessionId: string; participantId: string }
}) {
  const router = useRouter()
  const [session, setSession] = useState<QuizSession | null>(null)
  const [participant, setParticipant] = useState<Participant | null>(null)
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null)
  const [selectedAnswer, setSelectedAnswer] = useState<string>("")
  const [hasAnswered, setHasAnswered] = useState(false)
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null)
  const [timeLeft, setTimeLeft] = useState<number>(0)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const supabase = createClient()

  useEffect(() => {
    loadInitialData()
  }, [])

  useEffect(() => {
    if (session) {
      // Subscribe to session updates
      const sessionChannel = supabase
        .channel(`session-${session.id}`)
        .on(
          "postgres_changes",
          {
            event: "UPDATE",
            schema: "public",
            table: "quiz_sessions",
            filter: `id=eq.${session.id}`,
          },
          (payload) => {
            const updatedSession = payload.new as QuizSession
            setSession(updatedSession)

            if (updatedSession.status === "completed") {
              router.push(`/results/${session.id}/${params.participantId}`)
            } else if (updatedSession.status === "active") {
              loadCurrentQuestion(updatedSession.current_question_index)
              setHasAnswered(false)
              setSelectedAnswer("")
              setIsCorrect(null)
            }
          },
        )
        .subscribe()

      // Subscribe to participant updates
      const participantChannel = supabase
        .channel(`participant-${params.participantId}`)
        .on(
          "postgres_changes",
          {
            event: "UPDATE",
            schema: "public",
            table: "participants",
            filter: `id=eq.${params.participantId}`,
          },
          (payload) => {
            setParticipant(payload.new as Participant)
          },
        )
        .subscribe()

      return () => {
        supabase.removeChannel(sessionChannel)
        supabase.removeChannel(participantChannel)
      }
    }
  }, [session])

  useEffect(() => {
    if (session?.status === "active" && currentQuestion && timeLeft > 0 && !hasAnswered) {
      const timer = setTimeout(() => {
        setTimeLeft(timeLeft - 1)
      }, 1000)
      return () => clearTimeout(timer)
    }
  }, [timeLeft, session?.status, hasAnswered])

  const loadInitialData = async () => {
    try {
      // Load session
      const { data: sessionData, error: sessionError } = await supabase
        .from("quiz_sessions")
        .select(`
          *,
          quizzes (title, total_questions)
        `)
        .eq("id", params.sessionId)
        .single()

      if (sessionError) throw sessionError
      setSession(sessionData)

      // Load participant
      const { data: participantData, error: participantError } = await supabase
        .from("participants")
        .select("*")
        .eq("id", params.participantId)
        .single()

      if (participantError) throw participantError
      setParticipant(participantData)

      // Load current question if session is active
      if (sessionData.status === "active") {
        await loadCurrentQuestion(sessionData.current_question_index)
      }
    } catch (error: any) {
      setError(error.message)
    } finally {
      setIsLoading(false)
    }
  }

  const loadCurrentQuestion = async (questionIndex: number) => {
    try {
      const { data: questions, error } = await supabase
        .from("questions")
        .select("*")
        .eq("quiz_id", session?.quizzes?.id || "")
        .order("order_index")

      if (error) throw error

      const question = questions[questionIndex]
      if (question) {
        setCurrentQuestion(question)
        setTimeLeft(question.time_limit || 30)

        // Check if already answered this question
        const { data: existingAnswer } = await supabase
          .from("answers")
          .select("*")
          .eq("participant_id", params.participantId)
          .eq("question_id", question.id)
          .single()

        if (existingAnswer) {
          setHasAnswered(true)
          setSelectedAnswer(existingAnswer.answer)
          setIsCorrect(existingAnswer.is_correct)
        }
      }
    } catch (error: any) {
      console.error("Error loading question:", error)
    }
  }

  const submitAnswer = async (answer: string) => {
    if (!currentQuestion || !participant || hasAnswered) return

    setSelectedAnswer(answer)
    setHasAnswered(true)

    try {
      const isAnswerCorrect = answer === currentQuestion.correct_answer
      const responseTime = (currentQuestion.time_limit || 30) - timeLeft
      const pointsEarned = isAnswerCorrect ? currentQuestion.points : 0

      // Submit answer
      const { error: answerError } = await supabase.from("answers").insert({
        participant_id: params.participantId,
        question_id: currentQuestion.id,
        answer,
        is_correct: isAnswerCorrect,
        points_earned: pointsEarned,
        response_time: responseTime * 1000, // Convert to milliseconds
      })

      if (answerError) throw answerError

      // Update participant score and streak
      const newScore = participant.score + pointsEarned
      const newStreak = isAnswerCorrect ? participant.current_streak + 1 : 0
      const bestStreak = Math.max(participant.best_streak || 0, newStreak)

      const { error: participantError } = await supabase
        .from("participants")
        .update({
          score: newScore,
          current_streak: newStreak,
          best_streak: bestStreak,
        })
        .eq("id", params.participantId)

      if (participantError) throw participantError

      setIsCorrect(isAnswerCorrect)
    } catch (error: any) {
      setError(error.message)
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading quiz...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 via-background to-secondary/5 p-4">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="text-destructive">Error</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">{error}</p>
            <Button onClick={() => router.push("/")}>Go Home</Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h1 className="text-xl font-bold">{session?.quizzes.title}</h1>
              <Badge variant={session?.status === "active" ? "default" : "secondary"}>{session?.status}</Badge>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <div className="text-sm text-muted-foreground">Score</div>
                <div className="font-bold text-lg">{participant?.score || 0}</div>
              </div>
              <div className="text-right">
                <div className="text-sm text-muted-foreground">Streak</div>
                <div className="font-bold text-lg">{participant?.current_streak || 0}</div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {session?.status === "waiting" ? (
            /* Waiting Room */
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-2xl">Get Ready!</CardTitle>
                <CardDescription>Waiting for the host to start the quiz</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                  <Clock className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <div className="text-sm text-muted-foreground mb-2">You're playing as</div>
                  <div className="text-2xl font-bold">{participant?.nickname}</div>
                </div>
              </CardContent>
            </Card>
          ) : session?.status === "paused" ? (
            /* Paused State */
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-2xl">Quiz Paused</CardTitle>
                <CardDescription>The host has paused the quiz</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mx-auto w-16 h-16 bg-secondary/10 rounded-full flex items-center justify-center">
                  <Clock className="w-8 h-8 text-secondary" />
                </div>
              </CardContent>
            </Card>
          ) : currentQuestion ? (
            /* Active Question */
            <div className="space-y-6">
              {/* Progress and Timer */}
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="text-sm font-medium">
                      Question {(session?.current_question_index || 0) + 1} of {session?.quizzes.total_questions}
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      <span className="font-bold text-lg">{timeLeft}s</span>
                    </div>
                  </div>
                  <Progress
                    value={
                      (((session?.current_question_index || 0) + 1) / (session?.quizzes.total_questions || 1)) * 100
                    }
                  />
                </CardContent>
              </Card>

              {/* Question */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-2xl">{currentQuestion.question_text}</CardTitle>
                  <CardDescription>
                    {currentQuestion.points} points • {currentQuestion.time_limit}s
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {currentQuestion.question_type === "multiple_choice" && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {currentQuestion.options?.map((option, index) => (
                        <Button
                          key={index}
                          variant={selectedAnswer === option ? "default" : "outline"}
                          size="lg"
                          className={`h-auto p-6 text-left justify-start ${
                            hasAnswered
                              ? selectedAnswer === option
                                ? isCorrect
                                  ? "bg-accent border-accent animate-pulse-success"
                                  : "bg-destructive border-destructive animate-shake-error"
                                : option === currentQuestion.correct_answer
                                  ? "bg-accent/20 border-accent"
                                  : ""
                              : ""
                          }`}
                          onClick={() => submitAnswer(option)}
                          disabled={hasAnswered || timeLeft === 0}
                        >
                          <div className="flex items-center gap-3">
                            {hasAnswered &&
                              selectedAnswer === option &&
                              (isCorrect ? (
                                <CheckCircle className="w-5 h-5 text-accent" />
                              ) : (
                                <XCircle className="w-5 h-5 text-destructive" />
                              ))}
                            <span className="text-lg">{option}</span>
                          </div>
                        </Button>
                      ))}
                    </div>
                  )}

                  {currentQuestion.question_type === "true_false" && (
                    <div className="grid grid-cols-2 gap-4">
                      {["true", "false"].map((option) => (
                        <Button
                          key={option}
                          variant={selectedAnswer === option ? "default" : "outline"}
                          size="lg"
                          className={`h-20 text-xl ${
                            hasAnswered
                              ? selectedAnswer === option
                                ? isCorrect
                                  ? "bg-accent border-accent animate-pulse-success"
                                  : "bg-destructive border-destructive animate-shake-error"
                                : option === currentQuestion.correct_answer
                                  ? "bg-accent/20 border-accent"
                                  : ""
                              : ""
                          }`}
                          onClick={() => submitAnswer(option)}
                          disabled={hasAnswered || timeLeft === 0}
                        >
                          {option.charAt(0).toUpperCase() + option.slice(1)}
                        </Button>
                      ))}
                    </div>
                  )}

                  {hasAnswered && (
                    <div className="mt-6 text-center">
                      <div
                        className={`inline-flex items-center gap-2 px-4 py-2 rounded-full ${
                          isCorrect ? "bg-accent/10 text-accent" : "bg-destructive/10 text-destructive"
                        }`}
                      >
                        {isCorrect ? (
                          <>
                            <CheckCircle className="w-5 h-5" />
                            <span className="font-semibold">Correct! +{currentQuestion.points} points</span>
                          </>
                        ) : (
                          <>
                            <XCircle className="w-5 h-5" />
                            <span className="font-semibold">Incorrect</span>
                          </>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          ) : (
            /* Loading Question */
            <Card className="text-center">
              <CardContent className="pt-12 pb-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                <p>Loading next question...</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
