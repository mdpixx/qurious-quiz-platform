"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { Check, Crown, Zap, ArrowLeft, Smartphone } from "lucide-react"

interface SubscriptionPlan {
  id: string
  name: string
  description: string
  price_monthly: number
  price_yearly: number
  features: string[]
  max_quizzes: number | null
  max_participants_per_quiz: number | null
  max_questions_per_quiz: number | null
  custom_branding: boolean
  advanced_analytics: boolean
  priority_support: boolean
}

export default function PricingPage() {
  const router = useRouter()
  const [plans, setPlans] = useState<SubscriptionPlan[]>([])
  const [isYearly, setIsYearly] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [user, setUser] = useState<any>(null)

  const supabase = createClient()

  useEffect(() => {
    loadPlans()
    checkUser()
  }, [])

  const loadPlans = async () => {
    try {
      const { data, error } = await supabase
        .from("subscription_plans")
        .select("*")
        .eq("is_active", true)
        .order("price_monthly")

      if (error) throw error
      setPlans(data)
    } catch (error) {
      console.error("Error loading plans:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const checkUser = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser()
    setUser(user)
  }

  const handleSubscribe = async (plan: SubscriptionPlan) => {
    if (!user) {
      router.push("/auth/login")
      return
    }

    if (plan.name === "Free") {
      router.push("/dashboard")
      return
    }

    // Redirect to payment page
    router.push(`/payment?plan=${plan.id}&billing=${isYearly ? "yearly" : "monthly"}`)
  }

  const formatPrice = (monthly: number, yearly: number) => {
    if (monthly === 0) return "Free"
    const price = isYearly ? yearly : monthly
    return `₹${price.toLocaleString("en-IN")}`
  }

  const getPlanIcon = (planName: string) => {
    switch (planName.toLowerCase()) {
      case "free":
        return <Zap className="w-6 h-6 text-primary" />
      case "pro":
        return <Crown className="w-6 h-6 text-secondary" />
      case "enterprise":
        return <Crown className="w-6 h-6 text-accent" />
      default:
        return <Zap className="w-6 h-6" />
    }
  }

  const getPlanColor = (planName: string) => {
    switch (planName.toLowerCase()) {
      case "pro":
        return "border-secondary shadow-secondary/20"
      case "enterprise":
        return "border-accent shadow-accent/20"
      default:
        return "border-border"
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading pricing plans...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button asChild variant="ghost" size="sm">
                <Link href="/">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Link>
              </Button>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Choose Your Plan
              </h1>
            </div>
            {!user && (
              <Button asChild variant="outline">
                <Link href="/auth/login">Sign In</Link>
              </Button>
            )}
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Simple, Transparent Pricing</h2>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Choose the perfect plan for your quiz needs. All plans include UPI payments for seamless Indian
              transactions.
            </p>

            {/* Billing Toggle */}
            <div className="flex items-center justify-center gap-4 mb-8">
              <Label htmlFor="billing-toggle" className={!isYearly ? "font-semibold" : ""}>
                Monthly
              </Label>
              <Switch id="billing-toggle" checked={isYearly} onCheckedChange={setIsYearly} />
              <Label htmlFor="billing-toggle" className={isYearly ? "font-semibold" : ""}>
                Yearly
              </Label>
              {isYearly && <Badge className="bg-accent">Save up to 17%</Badge>}
            </div>

            {/* UPI Badge */}
            <div className="flex items-center justify-center gap-2 mb-8">
              <Smartphone className="w-5 h-5 text-primary" />
              <span className="text-sm text-muted-foreground">Supports UPI, Cards, Net Banking & Wallets</span>
            </div>
          </div>

          {/* Pricing Cards */}
          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan) => (
              <Card
                key={plan.id}
                className={`relative border-2 ${getPlanColor(plan.name)} ${
                  plan.name === "Pro" ? "scale-105 shadow-xl" : ""
                }`}
              >
                {plan.name === "Pro" && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-secondary text-secondary-foreground px-4 py-1">Most Popular</Badge>
                  </div>
                )}

                <CardHeader className="text-center pb-8">
                  <div className="mx-auto mb-4">{getPlanIcon(plan.name)}</div>
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <CardDescription className="text-base">{plan.description}</CardDescription>
                  <div className="mt-4">
                    <div className="text-4xl font-bold">{formatPrice(plan.price_monthly, plan.price_yearly)}</div>
                    {plan.price_monthly > 0 && (
                      <div className="text-sm text-muted-foreground">
                        per {isYearly ? "year" : "month"}
                        {isYearly && plan.price_monthly > 0 && (
                          <div className="text-xs">(₹{(plan.price_yearly / 12).toFixed(0)}/month billed annually)</div>
                        )}
                      </div>
                    )}
                  </div>
                </CardHeader>

                <CardContent className="space-y-6">
                  {/* Features */}
                  <div className="space-y-3">
                    {plan.features.map((feature, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <Check className="w-5 h-5 text-accent flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>

                  {/* Limits */}
                  <div className="pt-4 border-t space-y-2 text-sm text-muted-foreground">
                    <div>Quizzes: {plan.max_quizzes ? plan.max_quizzes : "Unlimited"}</div>
                    <div>
                      Participants:{" "}
                      {plan.max_participants_per_quiz ? `Up to ${plan.max_participants_per_quiz}` : "Unlimited"}
                    </div>
                    <div>
                      Questions: {plan.max_questions_per_quiz ? `Up to ${plan.max_questions_per_quiz}` : "Unlimited"}
                    </div>
                  </div>

                  <Button
                    onClick={() => handleSubscribe(plan)}
                    className="w-full"
                    variant={plan.name === "Pro" ? "default" : "outline"}
                    size="lg"
                  >
                    {plan.name === "Free" ? "Get Started" : `Choose ${plan.name}`}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* FAQ Section */}
          <div className="mt-16 text-center">
            <h3 className="text-2xl font-bold mb-8">Frequently Asked Questions</h3>
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">What payment methods do you accept?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    We support all major Indian payment methods including UPI (Google Pay, PhonePe, Paytm), Credit/Debit
                    Cards, Net Banking, and Digital Wallets.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Can I change plans anytime?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Yes! You can upgrade or downgrade your plan at any time. Changes take effect immediately and we'll
                    prorate the billing accordingly.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Is there a free trial?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Our Free plan lets you explore Qurious with no time limits. Upgrade to Pro or Enterprise when you're
                    ready for more features.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">What about refunds?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    We offer a 30-day money-back guarantee on all paid plans. If you're not satisfied, we'll refund your
                    payment in full.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
