import { createServerClient } from "@/lib/supabase/server"
import { cookies } from "next/headers"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Heart, Play, Users, Trophy, UserPlus, MessageCircle } from "lucide-react"
import Link from "next/link"
import { notFound } from "next/navigation"

interface ProfilePageProps {
  params: {
    id: string
  }
}

export default async function ProfilePage({ params }: ProfilePageProps) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)

  // Get current user
  const {
    data: { user },
  } = await supabase.auth.getUser()

  // Get profile data
  const { data: profile } = await supabase
    .from("profiles")
    .select(`
      *,
      quizzes:quizzes!creator_id (
        id,
        title,
        description,
        category,
        difficulty,
        is_public,
        created_at,
        quiz_likes (count),
        quiz_sessions (count)
      ),
      followers:follows!following_id (count),
      following:follows!follower_id (count)
    `)
    .eq("id", params.id)
    .single()

  if (!profile) {
    notFound()
  }

  // Check if current user follows this profile
  const { data: isFollowing } = user
    ? await supabase.from("follows").select("id").eq("follower_id", user.id).eq("following_id", params.id).single()
    : { data: null }

  // Get user stats
  const totalPlays = profile.quizzes?.reduce((sum, quiz) => sum + (quiz.quiz_sessions?.[0]?.count || 0), 0) || 0
  const totalLikes = profile.quizzes?.reduce((sum, quiz) => sum + (quiz.quiz_likes?.[0]?.count || 0), 0) || 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        {/* Profile Header */}
        <Card className="mb-8">
          <CardContent className="p-8">
            <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
              <Avatar className="h-24 w-24">
                <AvatarImage src={profile.avatar_url || "/placeholder.svg"} />
                <AvatarFallback className="text-2xl">{profile.full_name?.charAt(0) || "U"}</AvatarFallback>
              </Avatar>

              <div className="flex-1 text-center md:text-left">
                <h1 className="text-3xl font-bold text-slate-900 mb-2">{profile.full_name || "Anonymous User"}</h1>
                {profile.bio && <p className="text-slate-600 mb-4">{profile.bio}</p>}

                <div className="flex flex-wrap justify-center md:justify-start gap-6 mb-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-slate-900">{profile.quizzes?.length || 0}</div>
                    <div className="text-sm text-slate-600">Quizzes</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-slate-900">{profile.followers?.[0]?.count || 0}</div>
                    <div className="text-sm text-slate-600">Followers</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-slate-900">{profile.following?.[0]?.count || 0}</div>
                    <div className="text-sm text-slate-600">Following</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-slate-900">{totalPlays}</div>
                    <div className="text-sm text-slate-600">Total Plays</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-slate-900">{totalLikes}</div>
                    <div className="text-sm text-slate-600">Total Likes</div>
                  </div>
                </div>

                {user && user.id !== params.id && (
                  <div className="flex gap-3">
                    <Button className={isFollowing ? "bg-slate-600" : ""}>
                      <UserPlus className="h-4 w-4 mr-2" />
                      {isFollowing ? "Following" : "Follow"}
                    </Button>
                    <Button variant="outline">
                      <MessageCircle className="h-4 w-4 mr-2" />
                      Message
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Profile Content */}
        <Tabs defaultValue="quizzes" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="quizzes">Quizzes</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>

          <TabsContent value="quizzes">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {profile.quizzes
                ?.filter((quiz) => quiz.is_public || user?.id === params.id)
                .map((quiz) => (
                  <Card key={quiz.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <CardTitle className="text-lg">{quiz.title}</CardTitle>
                      <p className="text-sm text-slate-600">{quiz.description}</p>

                      <div className="flex items-center gap-4 text-sm text-slate-500">
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4" />
                          {quiz.quiz_sessions?.[0]?.count || 0} plays
                        </div>
                        <div className="flex items-center gap-1">
                          <Heart className="h-4 w-4" />
                          {quiz.quiz_likes?.[0]?.count || 0} likes
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent>
                      <div className="flex items-center justify-between">
                        <div className="flex gap-2">
                          <Badge variant="secondary">{quiz.category}</Badge>
                          <Badge variant="outline">{quiz.difficulty}</Badge>
                        </div>
                        <Button size="sm" asChild>
                          <Link href={`/quiz/${quiz.id}`}>
                            <Play className="h-4 w-4 mr-2" />
                            Play
                          </Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </TabsContent>

          <TabsContent value="achievements">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { name: "Quiz Master", description: "Created 10+ quizzes", icon: "🏆", earned: true },
                { name: "Popular Creator", description: "1000+ total plays", icon: "⭐", earned: totalPlays >= 1000 },
                { name: "Community Favorite", description: "100+ total likes", icon: "❤️", earned: totalLikes >= 100 },
                {
                  name: "Social Butterfly",
                  description: "50+ followers",
                  icon: "🦋",
                  earned: (profile.followers?.[0]?.count || 0) >= 50,
                },
                { name: "Trendsetter", description: "Quiz featured on trending", icon: "🔥", earned: false },
                { name: "Educator", description: "Education category expert", icon: "📚", earned: false },
              ].map((achievement) => (
                <Card
                  key={achievement.name}
                  className={`${achievement.earned ? "bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-200" : "opacity-50"}`}
                >
                  <CardContent className="p-6 text-center">
                    <div className="text-4xl mb-3">{achievement.icon}</div>
                    <h3 className="font-semibold text-lg text-slate-900 mb-2">{achievement.name}</h3>
                    <p className="text-sm text-slate-600">{achievement.description}</p>
                    {achievement.earned && <Badge className="mt-3 bg-yellow-500">Earned</Badge>}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="activity">
            <Card>
              <CardContent className="p-6">
                <div className="text-center py-12">
                  <Trophy className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">Activity Feed Coming Soon</h3>
                  <p className="text-slate-600">See recent quiz plays, achievements, and community interactions</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
