"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"
import { ArrowLeft, Play, Pause, SkipForward, Users, Copy, Check, QrCode, Sparkles, UserPlus } from "lucide-react"
import { useI18n } from "@/lib/i18n/context"

interface Quiz {
  id: string
  title: string
  description: string
  total_questions: number
}

interface Question {
  id: string
  question_text: string
  question_type: string
  options: string[]
  correct_answer: string
  points: number
  time_limit: number
  order_index: number
}

interface QuizSession {
  id: string
  session_code: string
  status: "waiting" | "active" | "paused" | "completed"
  current_question_index: number
}

interface Participant {
  id: string
  nickname: string
  score: number
  is_active: boolean
  avatar_color?: string
  anonymous_name?: string
}

const ANONYMOUS_NAMES = [
  "Clever Cat",
  "Smart Fox",
  "Wise Owl",
  "Quick Rabbit",
  "Bright Star",
  "Sharp Eagle",
  "Swift Dolphin",
  "Keen Wolf",
  "Alert Hawk",
  "Agile Cheetah",
  "Witty Parrot",
  "Savvy Bear",
  "Astute Lion",
  "Perceptive Tiger",
  "Insightful Panda",
  "Brilliant Phoenix",
  "Genius Falcon",
  "Intelligent Raven",
  "Shrewd Lynx",
  "Cunning Jaguar",
  "Resourceful Otter",
  "Inventive Bee",
  "Creative Butterfly",
  "Innovative Hummingbird",
  "Visionary Peacock",
  "Imaginative Unicorn",
]

const AVATAR_COLORS = [
  "bg-red-500",
  "bg-blue-500",
  "bg-green-500",
  "bg-yellow-500",
  "bg-purple-500",
  "bg-pink-500",
  "bg-indigo-500",
  "bg-teal-500",
  "bg-orange-500",
  "bg-cyan-500",
  "bg-emerald-500",
  "bg-violet-500",
  "bg-rose-500",
  "bg-amber-500",
  "bg-lime-500",
]

export default function HostQuizPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { t } = useI18n()
  const [quiz, setQuiz] = useState<Quiz | null>(null)
  const [questions, setQuestions] = useState<Question[]>([])
  const [session, setSession] = useState<QuizSession | null>(null)
  const [participants, setParticipants] = useState<Participant[]>([])
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null)
  const [timeLeft, setTimeLeft] = useState<number>(0)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [recentJoins, setRecentJoins] = useState<string[]>([])
  const [participantCount, setParticipantCount] = useState(0)

  const supabase = createClient()

  useEffect(() => {
    loadQuizData()
  }, [params.id])

  useEffect(() => {
    if (session) {
      const sessionChannel = supabase
        .channel(`session-${session.id}`)
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "quiz_sessions",
            filter: `id=eq.${session.id}`,
          },
          (payload) => {
            setSession(payload.new as QuizSession)
          },
        )
        .subscribe()

      const participantsChannel = supabase
        .channel(`participants-${session.id}`)
        .on(
          "postgres_changes",
          {
            event: "INSERT",
            schema: "public",
            table: "participants",
            filter: `session_id=eq.${session.id}`,
          },
          (payload) => {
            const newParticipant = payload.new as Participant
            const enhancedParticipant = {
              ...newParticipant,
              ...assignAnonymousIdentity(newParticipant.id),
            }

            setParticipants((prev) => [...prev, enhancedParticipant])
            setParticipantCount((prev) => prev + 1)

            const displayName = enhancedParticipant.anonymous_name || enhancedParticipant.nickname
            setRecentJoins((prev) => [...prev, displayName])
            setTimeout(() => {
              setRecentJoins((prev) => prev.filter((name) => name !== displayName))
            }, 4000)
          },
        )
        .on(
          "postgres_changes",
          {
            event: "DELETE",
            schema: "public",
            table: "participants",
            filter: `session_id=eq.${session.id}`,
          },
          () => {
            loadParticipants()
            setParticipantCount((prev) => Math.max(0, prev - 1))
          },
        )
        .on(
          "postgres_changes",
          {
            event: "UPDATE",
            schema: "public",
            table: "participants",
            filter: `session_id=eq.${session.id}`,
          },
          () => {
            loadParticipants()
          },
        )
        .subscribe()

      return () => {
        supabase.removeChannel(sessionChannel)
        supabase.removeChannel(participantsChannel)
      }
    }
  }, [session])

  useEffect(() => {
    if (session?.status === "active" && currentQuestion && timeLeft > 0) {
      const timer = setTimeout(() => {
        setTimeLeft(timeLeft - 1)
      }, 1000)
      return () => clearTimeout(timer)
    } else if (timeLeft === 0 && session?.status === "active") {
      nextQuestion()
    }
  }, [timeLeft, session?.status])

  const loadQuizData = async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) throw new Error("Not authenticated")

      const { data: quizData, error: quizError } = await supabase
        .from("quizzes")
        .select("*")
        .eq("id", params.id)
        .eq("creator_id", user.id)
        .single()

      if (quizError) throw quizError
      setQuiz(quizData)

      const { data: questionsData, error: questionsError } = await supabase
        .from("questions")
        .select("*")
        .eq("quiz_id", params.id)
        .order("order_index")

      if (questionsError) throw questionsError
      setQuestions(questionsData)

      const { data: existingSession } = await supabase
        .from("quiz_sessions")
        .select("*")
        .eq("quiz_id", params.id)
        .eq("host_id", user.id)
        .in("status", ["waiting", "active", "paused"])
        .single()

      if (existingSession) {
        setSession(existingSession)
        if (existingSession.status === "active") {
          setCurrentQuestion(questionsData[existingSession.current_question_index])
          setTimeLeft(questionsData[existingSession.current_question_index]?.time_limit || 30)
        }
        loadParticipants(existingSession.id)
      }
    } catch (error: any) {
      setError(error.message)
    } finally {
      setIsLoading(false)
    }
  }

  const loadParticipants = async (sessionId?: string) => {
    if (!session && !sessionId) return

    const { data, error } = await supabase
      .from("participants")
      .select("*")
      .eq("session_id", sessionId || session!.id)
      .order("score", { ascending: false })

    if (!error) {
      const enhancedParticipants = data.map((participant) => ({
        ...participant,
        ...assignAnonymousIdentity(participant.id),
      }))
      setParticipants(enhancedParticipants)
      setParticipantCount(enhancedParticipants.length)
    }
  }

  const createSession = async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) throw new Error("Not authenticated")

      const { data: sessionData, error } = await supabase
        .from("quiz_sessions")
        .insert({
          quiz_id: params.id,
          host_id: user.id,
          session_code: await generateSessionCode(),
          status: "waiting",
          current_question_index: 0,
        })
        .select()
        .single()

      if (error) throw error
      setSession(sessionData)
    } catch (error: any) {
      setError(error.message)
    }
  }

  const generateSessionCode = async (): Promise<string> => {
    const code = Math.floor(100000 + Math.random() * 900000).toString()

    const { data } = await supabase.from("quiz_sessions").select("id").eq("session_code", code).single()

    if (data) {
      return generateSessionCode()
    }

    return code
  }

  const startQuiz = async () => {
    if (!session || questions.length === 0) return

    try {
      const { error } = await supabase
        .from("quiz_sessions")
        .update({
          status: "active",
          started_at: new Date().toISOString(),
        })
        .eq("id", session.id)

      if (error) throw error

      setCurrentQuestion(questions[0])
      setTimeLeft(questions[0].time_limit || 30)
    } catch (error: any) {
      setError(error.message)
    }
  }

  const pauseQuiz = async () => {
    if (!session) return

    try {
      const { error } = await supabase.from("quiz_sessions").update({ status: "paused" }).eq("id", session.id)

      if (error) throw error
    } catch (error: any) {
      setError(error.message)
    }
  }

  const resumeQuiz = async () => {
    if (!session) return

    try {
      const { error } = await supabase.from("quiz_sessions").update({ status: "active" }).eq("id", session.id)

      if (error) throw error

      if (currentQuestion) {
        setTimeLeft(currentQuestion.time_limit || 30)
      }
    } catch (error: any) {
      setError(error.message)
    }
  }

  const nextQuestion = async () => {
    if (!session || !questions.length) return

    const nextIndex = session.current_question_index + 1

    if (nextIndex >= questions.length) {
      const { error } = await supabase
        .from("quiz_sessions")
        .update({
          status: "completed",
          ended_at: new Date().toISOString(),
        })
        .eq("id", session.id)

      if (!error) {
        router.push(`/quiz/${params.id}/results/${session.id}`)
      }
      return
    }

    try {
      const { error } = await supabase
        .from("quiz_sessions")
        .update({ current_question_index: nextIndex })
        .eq("id", session.id)

      if (error) throw error

      setCurrentQuestion(questions[nextIndex])
      setTimeLeft(questions[nextIndex].time_limit || 30)
    } catch (error: any) {
      setError(error.message)
    }
  }

  const copySessionCode = () => {
    if (session?.session_code) {
      navigator.clipboard.writeText(session.session_code)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const generateQRCode = (text: string) => {
    const size = 200
    const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(text)}&bgcolor=ffffff&color=000000&margin=10`
    return qrApiUrl
  }

  const assignAnonymousIdentity = (participantId: string) => {
    const nameIndex =
      Math.abs(participantId.split("").reduce((a, b) => a + b.charCodeAt(0), 0)) % ANONYMOUS_NAMES.length
    const colorIndex = Math.abs(participantId.split("").reduce((a, b) => a + b.charCodeAt(0), 0)) % AVATAR_COLORS.length

    return {
      anonymous_name: ANONYMOUS_NAMES[nameIndex],
      avatar_color: AVATAR_COLORS[colorIndex],
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>{t("loadingQuiz")}</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="text-destructive">{t("error")}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">{error}</p>
            <Button asChild>
              <Link href="/dashboard">{t("backToDashboard")}</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5">
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button asChild variant="ghost" size="sm">
                <Link href={`/quiz/${params.id}`}>
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  {t("back")}
                </Link>
              </Button>
              <h1 className="text-xl font-bold">{quiz?.title}</h1>
              {session && (
                <Badge variant={session.status === "active" ? "default" : "secondary"}>
                  <Sparkles className="w-3 h-3 mr-1" />
                  {session.status}
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-4">
              {session && (
                <div className="flex items-center gap-2 bg-primary/10 px-3 py-1 rounded-full relative">
                  <Users className="w-4 h-4 text-primary" />
                  <span className="font-semibold text-primary">{participantCount}</span>
                  <span className="text-sm text-muted-foreground">{t("live")}</span>
                  {recentJoins.length > 0 && (
                    <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full animate-ping"></div>
                  )}
                </div>
              )}
              {recentJoins.length > 0 && (
                <div className="bg-green-100 border border-green-300 px-3 py-1 rounded-full animate-in slide-in-from-right duration-300">
                  <div className="flex items-center gap-2 text-green-700 text-sm">
                    <UserPlus className="w-4 h-4" />
                    <span className="font-medium">{recentJoins[recentJoins.length - 1]} joined!</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {!session ? (
          <div className="max-w-2xl mx-auto">
            <Card>
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">{t("readyToHost")}</CardTitle>
                <CardDescription>{t("createLiveSession")}</CardDescription>
              </CardHeader>
              <CardContent className="text-center space-y-6">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="font-semibold">{t("questions")}</div>
                    <div className="text-muted-foreground">{questions.length}</div>
                  </div>
                  <div>
                    <div className="font-semibold">{t("estimatedTime")}</div>
                    <div className="text-muted-foreground">
                      {Math.ceil(questions.reduce((sum, q) => sum + (q.time_limit || 30), 0) / 60)} {t("min")}
                    </div>
                  </div>
                </div>
                <Button onClick={createSession} size="lg" className="w-full">
                  {t("createLiveSession")}
                </Button>
              </CardContent>
            </Card>
          </div>
        ) : session.status === "waiting" ? (
          <div className="max-w-6xl mx-auto">
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <Card className="border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-secondary/5">
                  <CardHeader className="text-center">
                    <CardTitle className="text-3xl flex items-center justify-center gap-2">
                      <QrCode className="w-8 h-8 text-primary" />
                      {t("sessionCode")}
                    </CardTitle>
                    <CardDescription className="text-lg">{t("shareCodeWithParticipants")}</CardDescription>
                  </CardHeader>
                  <CardContent className="text-center space-y-8">
                    <div className="grid md:grid-cols-2 gap-8 items-center">
                      <div className="space-y-4">
                        <div className="bg-white p-4 rounded-xl shadow-lg inline-block">
                          <img
                            src={generateQRCode(
                              `${window.location.origin || "/placeholder.svg"}/join/${session.session_code || "/placeholder.svg"}`,
                            )}
                            alt="QR Code to join quiz"
                            className="w-48 h-48 mx-auto"
                          />
                        </div>
                        <p className="text-sm text-muted-foreground font-medium">{t("scanToJoin")}</p>
                      </div>
                      <div className="space-y-6">
                        <div className="text-7xl font-bold text-primary tracking-wider font-mono bg-white/50 py-4 px-6 rounded-2xl shadow-inner">
                          {session.session_code}
                        </div>
                        <Button
                          onClick={copySessionCode}
                          variant="outline"
                          size="lg"
                          className="w-full bg-white/50 hover:bg-white/80"
                        >
                          {copied ? (
                            <Check className="w-5 h-5 mr-2 text-green-600" />
                          ) : (
                            <Copy className="w-5 h-5 mr-2" />
                          )}
                          {copied ? t("copied") : t("copyCode")}
                        </Button>
                        <div className="text-sm text-muted-foreground bg-white/30 p-3 rounded-lg">
                          <strong>{t("orVisit")}:</strong>
                          <br />
                          <span className="font-mono text-primary">
                            {window.location.origin}/join/{session.session_code}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              <Card className="border-2 border-secondary/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-secondary" />
                    {t("participants")} ({participants.length})
                  </CardTitle>
                  <CardDescription>
                    {participants.length === 0 ? t("waitingForPlayers") : t("playersReady")}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {participants.map((participant, index) => (
                      <div
                        key={participant.id}
                        className="flex items-center gap-3 p-3 bg-gradient-to-r from-white/50 to-secondary/10 rounded-lg border border-secondary/20 animate-in slide-in-from-right duration-500"
                        style={{ animationDelay: `${index * 100}ms` }}
                      >
                        <div
                          className={`w-10 h-10 rounded-full ${participant.avatar_color} flex items-center justify-center text-white font-bold text-sm shadow-lg`}
                        >
                          {participant.anonymous_name?.charAt(0) || participant.nickname?.charAt(0) || "?"}
                        </div>
                        <div className="flex-1">
                          <div className="font-semibold text-sm">
                            {participant.anonymous_name || participant.nickname}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {t("joined")} • {t("ready")}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                          <Badge variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
                            {t("ready")}
                          </Badge>
                        </div>
                      </div>
                    ))}
                    {participants.length === 0 && (
                      <div className="text-center py-12 space-y-4">
                        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto">
                          <Users className="w-8 h-8 text-muted-foreground" />
                        </div>
                        <div className="space-y-2">
                          <p className="font-medium text-muted-foreground">{t("noParticipantsYet")}</p>
                          <p className="text-sm text-muted-foreground">{t("shareSessionCodeToStart")}</p>
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="mt-6 space-y-4">
                    {participants.length > 0 && (
                      <div className="text-center p-3 bg-primary/10 rounded-lg border border-primary/20">
                        <div className="text-sm text-primary font-medium">
                          🎉 {participants.length} {participants.length === 1 ? t("playerReady") : t("playersReady")}
                        </div>
                      </div>
                    )}
                    <Button onClick={startQuiz} disabled={participants.length === 0} className="w-full" size="lg">
                      <Play className="w-5 h-5 mr-2" />
                      {participants.length === 0
                        ? t("waitingForPlayers")
                        : `${t("startQuiz")} (${participants.length} ${participants.length === 1 ? t("player") : t("players")})`}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        ) : (
          <div className="max-w-6xl mx-auto">
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm font-medium">
                        {t("question")} {(session.current_question_index || 0) + 1} {t("of")} {questions.length}
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{timeLeft}s</Badge>
                        {session.status === "paused" && <Badge variant="secondary">{t("paused")}</Badge>}
                      </div>
                    </div>
                    <Progress value={(((session.current_question_index || 0) + 1) / questions.length) * 100} />
                  </CardHeader>
                  <CardContent>
                    {currentQuestion && (
                      <div className="space-y-6">
                        <h2 className="text-2xl font-bold">{currentQuestion.question_text}</h2>
                        {currentQuestion.question_type === "multiple_choice" && (
                          <div className="grid grid-cols-2 gap-4">
                            {currentQuestion.options?.map((option, index) => (
                              <div
                                key={index}
                                className={`p-4 rounded-lg border-2 text-center font-semibold ${
                                  option === currentQuestion.correct_answer
                                    ? "border-accent bg-accent/10 text-accent"
                                    : "border-muted bg-muted/50"
                                }`}
                              >
                                {option}
                              </div>
                            ))}
                          </div>
                        )}
                        <div className="flex items-center justify-between">
                          <div className="text-sm text-muted-foreground">
                            {t("points")}: {currentQuestion.points}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {t("correct")}: {currentQuestion.correct_answer}
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
                <Card className="mt-4">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-4">
                      {session.status === "active" ? (
                        <Button onClick={pauseQuiz} variant="outline">
                          <Pause className="w-4 h-4 mr-2" />
                          {t("pause")}
                        </Button>
                      ) : (
                        <Button onClick={resumeQuiz}>
                          <Play className="w-4 h-4 mr-2" />
                          {t("resume")}
                        </Button>
                      )}
                      <Button onClick={nextQuestion}>
                        <SkipForward className="w-4 h-4 mr-2" />
                        {t("nextQuestion")}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-accent" />
                      {t("liveLeaderboard")}
                    </CardTitle>
                    <CardDescription>
                      {participants.length} {t("participants")}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {participants
                        .sort((a, b) => b.score - a.score)
                        .map((participant, index) => (
                          <div
                            key={participant.id}
                            className={`flex items-center gap-3 p-3 rounded-lg transition-all duration-300 ${
                              index === 0
                                ? "bg-gradient-to-r from-yellow-100 to-yellow-50 border-2 border-yellow-300 shadow-lg"
                                : index === 1
                                  ? "bg-gradient-to-r from-gray-100 to-gray-50 border-2 border-gray-300"
                                  : index === 2
                                    ? "bg-gradient-to-r from-orange-100 to-orange-50 border-2 border-orange-300"
                                    : "bg-muted hover:bg-muted/80"
                            }`}
                          >
                            <div
                              className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shadow-md ${
                                index === 0
                                  ? "bg-yellow-500 text-white"
                                  : index === 1
                                    ? "bg-gray-500 text-white"
                                    : index === 2
                                      ? "bg-orange-500 text-white"
                                      : "bg-muted-foreground text-muted"
                              }`}
                            >
                              {index + 1}
                            </div>
                            <div
                              className={`w-8 h-8 rounded-full ${participant.avatar_color} flex items-center justify-center text-white font-bold text-xs shadow-md`}
                            >
                              {participant.anonymous_name?.charAt(0) || participant.nickname?.charAt(0) || "?"}
                            </div>
                            <div className="flex-1">
                              <div className="font-semibold text-sm">
                                {participant.anonymous_name || participant.nickname}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {participant.score} {t("points")}
                              </div>
                            </div>
                            <Badge variant={index < 3 ? "default" : "outline"} className="font-bold">
                              {participant.score}
                            </Badge>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
