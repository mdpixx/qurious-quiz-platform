import { redirect } from "next/navigation"
import { createServerClient } from "@/lib/supabase/server"
import { cookies } from "next/headers"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { ArrowLeft, Play, Edit, Share, Users, Clock, Trophy } from "lucide-react"

interface QuizPageProps {
  params: {
    id: string
  }
}

export default async function QuizPage({ params }: QuizPageProps) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)
  const {
    data: { user },
  } = await supabase.auth.getUser()

  // Get quiz details
  const { data: quiz, error } = await supabase
    .from("quizzes")
    .select(`
      *,
      profiles:creator_id (display_name, username)
    `)
    .eq("id", params.id)
    .single()

  if (error || !quiz) {
    redirect("/dashboard")
  }

  // Get questions count
  const { count: questionsCount } = await supabase
    .from("questions")
    .select("*", { count: "exact", head: true })
    .eq("quiz_id", params.id)

  const isOwner = user?.id === quiz.creator_id

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button asChild variant="ghost" size="sm">
              <Link href="/dashboard">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Link>
            </Button>
            {isOwner && (
              <div className="flex items-center gap-2">
                <Button asChild variant="outline" size="sm">
                  <Link href={`/quiz/${params.id}/edit`}>
                    <Edit className="w-4 h-4 mr-2" />
                    Edit
                  </Link>
                </Button>
                <Button asChild size="sm">
                  <Link href={`/quiz/${params.id}/host`}>
                    <Play className="w-4 h-4 mr-2" />
                    Host Live
                  </Link>
                </Button>
              </div>
            )}
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Quiz Header */}
          <Card className="mb-8">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-3xl mb-2">{quiz.title}</CardTitle>
                  <CardDescription className="text-lg mb-4">{quiz.description}</CardDescription>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span>Created by {quiz.profiles?.display_name || "Unknown"}</span>
                    <span>•</span>
                    <span>{new Date(quiz.created_at).toLocaleDateString()}</span>
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <Badge variant={quiz.is_public ? "default" : "secondary"}>
                    {quiz.is_public ? "Public" : "Private"}
                  </Badge>
                  <Badge variant="outline">{quiz.difficulty}</Badge>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Quiz Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Questions</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{questionsCount || 0}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Plays</CardTitle>
                <Play className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{quiz.total_plays || 0}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Time per Question</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{quiz.time_limit}s</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Average Score</CardTitle>
                <Trophy className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{quiz.average_score || 0}%</div>
              </CardContent>
            </Card>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 mb-8">
            {isOwner ? (
              <>
                <Button asChild size="lg" className="flex-1">
                  <Link href={`/quiz/${params.id}/host`}>
                    <Play className="w-5 h-5 mr-2" />
                    Host Live Quiz
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="flex-1 bg-transparent">
                  <Link href={`/quiz/${params.id}/edit`}>
                    <Edit className="w-5 h-5 mr-2" />
                    Edit Quiz
                  </Link>
                </Button>
              </>
            ) : (
              <>
                <Button asChild size="lg" className="flex-1">
                  <Link href={`/quiz/${params.id}/play`}>
                    <Play className="w-5 h-5 mr-2" />
                    Play Quiz
                  </Link>
                </Button>
                <Button variant="outline" size="lg" className="flex-1 bg-transparent">
                  <Share className="w-5 h-5 mr-2" />
                  Share Quiz
                </Button>
              </>
            )}
          </div>

          {/* Quiz Details */}
          <Card>
            <CardHeader>
              <CardTitle>Quiz Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-2">Category</h4>
                  <p className="text-muted-foreground">{quiz.category || "General"}</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Language</h4>
                  <p className="text-muted-foreground">{quiz.language || "English"}</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Difficulty</h4>
                  <Badge variant="outline">{quiz.difficulty}</Badge>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Visibility</h4>
                  <Badge variant={quiz.is_public ? "default" : "secondary"}>
                    {quiz.is_public ? "Public" : "Private"}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
