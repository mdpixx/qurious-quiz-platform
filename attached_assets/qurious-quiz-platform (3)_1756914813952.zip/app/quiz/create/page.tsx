"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { ArrowLeft, Plus, Trash2, Save } from "lucide-react"
import Link from "next/link"

interface Question {
  id: string
  question_text: string
  question_type: "multiple_choice" | "true_false" | "short_answer" | "poll"
  options: string[]
  correct_answer: string
  points: number
  time_limit?: number
}

export default function CreateQuizPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Quiz metadata
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [category, setCategory] = useState("")
  const [difficulty, setDifficulty] = useState<"easy" | "medium" | "hard">("medium")
  const [isPublic, setIsPublic] = useState(true)
  const [timeLimit, setTimeLimit] = useState<number>(30)

  // Questions
  const [questions, setQuestions] = useState<Question[]>([])
  const [currentQuestion, setCurrentQuestion] = useState<Question>({
    id: crypto.randomUUID(),
    question_text: "",
    question_type: "multiple_choice",
    options: ["", "", "", ""],
    correct_answer: "",
    points: 10,
    time_limit: 30,
  })

  const addQuestion = () => {
    if (!currentQuestion.question_text.trim()) {
      setError("Please enter a question")
      return
    }

    if (currentQuestion.question_type === "multiple_choice" && currentQuestion.options.some((opt) => !opt.trim())) {
      setError("Please fill in all answer options")
      return
    }

    if (!currentQuestion.correct_answer.trim()) {
      setError("Please specify the correct answer")
      return
    }

    setQuestions([...questions, { ...currentQuestion }])
    setCurrentQuestion({
      id: crypto.randomUUID(),
      question_text: "",
      question_type: "multiple_choice",
      options: ["", "", "", ""],
      correct_answer: "",
      points: 10,
      time_limit: 30,
    })
    setError(null)
  }

  const removeQuestion = (id: string) => {
    setQuestions(questions.filter((q) => q.id !== id))
  }

  const updateCurrentQuestionOption = (index: number, value: string) => {
    const newOptions = [...currentQuestion.options]
    newOptions[index] = value
    setCurrentQuestion({ ...currentQuestion, options: newOptions })
  }

  const saveQuiz = async () => {
    console.log("[v0] Starting quiz creation process")

    if (!title.trim()) {
      setError("Please enter a quiz title")
      return
    }

    if (questions.length === 0) {
      setError("Please add at least one question")
      return
    }

    console.log("[v0] Quiz validation passed, proceeding with save")
    console.log("[v0] Quiz data:", {
      title,
      description,
      category,
      difficulty,
      isPublic,
      timeLimit,
      questionsCount: questions.length,
    })

    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()
      console.log("[v0] Supabase client created")

      const {
        data: { user },
      } = await supabase.auth.getUser()

      console.log("[v0] User authentication check:", { user: user ? { id: user.id, email: user.email } : null })

      if (!user) {
        throw new Error("You must be logged in to create a quiz")
      }

      console.log("[v0] Checking if user profile exists")
      const { data: existingProfile } = await supabase.from("profiles").select("id").eq("id", user.id).single()

      if (!existingProfile) {
        console.log("[v0] Profile not found, creating profile for user")
        const { error: profileError } = await supabase.from("profiles").insert({
          id: user.id,
          email: user.email,
          full_name: user.email,
          username: user.email?.split("@")[0] || "user",
          preferred_language: "en",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })

        if (profileError) {
          console.error("[v0] Profile creation error:", profileError)
          // Don't throw here, continue with quiz creation as the trigger might have created it
        } else {
          console.log("[v0] Profile created successfully")
        }
      } else {
        console.log("[v0] Profile exists, proceeding with quiz creation")
      }

      console.log("[v0] Attempting to create quiz in database")

      // Create quiz
      const { data: quiz, error: quizError } = await supabase
        .from("quizzes")
        .insert({
          title,
          description,
          creator_id: user.id,
          is_public: isPublic,
          category,
          difficulty,
          time_limit: timeLimit,
        })
        .select()
        .single()

      console.log("[v0] Quiz creation result:", { quiz, quizError })

      if (quizError) {
        console.error("[v0] Quiz creation error:", quizError)
        throw quizError
      }

      console.log("[v0] Quiz created successfully, now creating questions")

      // Create questions
      const questionsToInsert = questions.map((q, index) => ({
        quiz_id: quiz.id,
        question_text: q.question_text,
        question_type: q.question_type,
        options: q.question_type === "multiple_choice" ? q.options : null,
        correct_answer: q.correct_answer,
        points: q.points,
        time_limit: q.time_limit,
        order_index: index,
      }))

      console.log("[v0] Questions to insert:", questionsToInsert)

      const { error: questionsError } = await supabase.from("questions").insert(questionsToInsert)

      console.log("[v0] Questions creation result:", { questionsError })

      if (questionsError) {
        console.error("[v0] Questions creation error:", questionsError)
        throw questionsError
      }

      console.log("[v0] Quiz and questions created successfully, redirecting to dashboard")
      router.push("/dashboard")
    } catch (error: any) {
      console.error("[v0] Quiz creation failed:", error)
      setError(error.message)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button asChild variant="ghost" size="sm">
                <Link href="/dashboard">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Link>
              </Button>
              <h1 className="text-xl font-bold">Create New Quiz</h1>
            </div>
            <Button onClick={saveQuiz} disabled={isLoading}>
              <Save className="w-4 h-4 mr-2" />
              {isLoading ? "Saving..." : "Save Quiz"}
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Quiz Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Quiz Settings</CardTitle>
              <CardDescription>Configure your quiz details and settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title">Quiz Title *</Label>
                <Input
                  id="title"
                  placeholder="Enter quiz title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe your quiz"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Input
                    id="category"
                    placeholder="e.g., Science, History"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="difficulty">Difficulty</Label>
                  <Select
                    value={difficulty}
                    onValueChange={(value: "easy" | "medium" | "hard") => setDifficulty(value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="easy">Easy</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="hard">Hard</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="timeLimit">Time per Question (seconds)</Label>
                <Input
                  id="timeLimit"
                  type="number"
                  min="5"
                  max="300"
                  value={timeLimit}
                  onChange={(e) => setTimeLimit(Number(e.target.value))}
                />
              </div>

              <div className="flex items-center space-x-2">
                <Switch id="isPublic" checked={isPublic} onCheckedChange={setIsPublic} />
                <Label htmlFor="isPublic">Make quiz public</Label>
              </div>

              {/* Questions Summary */}
              <div className="space-y-2">
                <Label>Questions ({questions.length})</Label>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {questions.map((q, index) => (
                    <div key={q.id} className="flex items-center justify-between p-2 bg-muted rounded">
                      <span className="text-sm truncate flex-1">
                        {index + 1}. {q.question_text}
                      </span>
                      <Button variant="ghost" size="sm" onClick={() => removeQuestion(q.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Add Question */}
          <Card>
            <CardHeader>
              <CardTitle>Add Question</CardTitle>
              <CardDescription>Create questions for your quiz</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="questionText">Question *</Label>
                <Textarea
                  id="questionText"
                  placeholder="Enter your question"
                  value={currentQuestion.question_text}
                  onChange={(e) => setCurrentQuestion({ ...currentQuestion, question_text: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="questionType">Question Type</Label>
                <Select
                  value={currentQuestion.question_type}
                  onValueChange={(value: "multiple_choice" | "true_false" | "short_answer" | "poll") =>
                    setCurrentQuestion({ ...currentQuestion, question_type: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                    <SelectItem value="true_false">True/False</SelectItem>
                    <SelectItem value="short_answer">Short Answer</SelectItem>
                    <SelectItem value="poll">Poll</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Answer Options */}
              {currentQuestion.question_type === "multiple_choice" && (
                <div className="space-y-2">
                  <Label>Answer Options *</Label>
                  {currentQuestion.options.map((option, index) => (
                    <Input
                      key={index}
                      placeholder={`Option ${index + 1}`}
                      value={option}
                      onChange={(e) => updateCurrentQuestionOption(index, e.target.value)}
                    />
                  ))}
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="correctAnswer">Correct Answer *</Label>
                {currentQuestion.question_type === "multiple_choice" ? (
                  <Select
                    value={currentQuestion.correct_answer}
                    onValueChange={(value) => setCurrentQuestion({ ...currentQuestion, correct_answer: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select correct answer" />
                    </SelectTrigger>
                    <SelectContent>
                      {currentQuestion.options
                        .map((option, index) => ({ option, index }))
                        .filter(({ option }) => option.trim())
                        .map(({ option, index }) => (
                          <SelectItem key={index} value={option}>
                            {option}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                ) : currentQuestion.question_type === "true_false" ? (
                  <Select
                    value={currentQuestion.correct_answer}
                    onValueChange={(value) => setCurrentQuestion({ ...currentQuestion, correct_answer: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select correct answer" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="true">True</SelectItem>
                      <SelectItem value="false">False</SelectItem>
                    </SelectContent>
                  </Select>
                ) : (
                  <Input
                    placeholder="Enter correct answer"
                    value={currentQuestion.correct_answer}
                    onChange={(e) => setCurrentQuestion({ ...currentQuestion, correct_answer: e.target.value })}
                  />
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="points">Points</Label>
                  <Input
                    id="points"
                    type="number"
                    min="1"
                    max="100"
                    value={currentQuestion.points}
                    onChange={(e) => setCurrentQuestion({ ...currentQuestion, points: Number(e.target.value) })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="questionTimeLimit">Time Limit (seconds)</Label>
                  <Input
                    id="questionTimeLimit"
                    type="number"
                    min="5"
                    max="300"
                    value={currentQuestion.time_limit}
                    onChange={(e) => setCurrentQuestion({ ...currentQuestion, time_limit: Number(e.target.value) })}
                  />
                </div>
              </div>

              {error && (
                <div className="p-3 text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-lg">
                  {error}
                </div>
              )}

              <Button onClick={addQuestion} className="w-full">
                <Plus className="w-4 h-4 mr-2" />
                Add Question
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
