"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"
import { Trophy, Medal, Award, Users, Target, Zap, Home } from "lucide-react"

interface QuizSession {
  id: string
  quizzes: {
    title: string
    total_questions: number
    creator_id: string
  }
}

interface Participant {
  id: string
  nickname: string
  score: number
  best_streak: number
  user_id: string | null
}

interface Answer {
  id: string
  is_correct: boolean
  points_earned: number
  response_time: number
  questions: {
    question_text: string
    correct_answer: string
  }
}

interface LeaderboardEntry {
  participant: Participant
  rank: number
  total_participants: number
}

export default function QuizResultsPage({
  params,
}: {
  params: { sessionId: string; participantId: string }
}) {
  const [session, setSession] = useState<QuizSession | null>(null)
  const [participant, setParticipant] = useState<Participant | null>(null)
  const [answers, setAnswers] = useState<Answer[]>([])
  const [leaderboard, setLeaderboard] = useState<Participant[]>([])
  const [userRank, setUserRank] = useState<number>(0)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const supabase = createClient()

  useEffect(() => {
    loadResults()
  }, [])

  const loadResults = async () => {
    try {
      // Load session
      const { data: sessionData, error: sessionError } = await supabase
        .from("quiz_sessions")
        .select(`
          *,
          quizzes (title, total_questions, creator_id)
        `)
        .eq("id", params.sessionId)
        .single()

      if (sessionError) throw sessionError
      setSession(sessionData)

      // Load participant
      const { data: participantData, error: participantError } = await supabase
        .from("participants")
        .select("*")
        .eq("id", params.participantId)
        .single()

      if (participantError) throw participantError
      setParticipant(participantData)

      // Load all participants for leaderboard
      const { data: participantsData, error: participantsError } = await supabase
        .from("participants")
        .select("*")
        .eq("session_id", params.sessionId)
        .order("score", { ascending: false })

      if (participantsError) throw participantsError
      setLeaderboard(participantsData)

      // Find user rank
      const rank = participantsData.findIndex((p) => p.id === params.participantId) + 1
      setUserRank(rank)

      // Load user's answers
      const { data: answersData, error: answersError } = await supabase
        .from("answers")
        .select(`
          *,
          questions (question_text, correct_answer)
        `)
        .eq("participant_id", params.participantId)
        .order("answered_at")

      if (answersError) throw answersError
      setAnswers(answersData)

      // Update user profile points if logged in
      if (participantData.user_id) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("total_points")
          .eq("id", participantData.user_id)
          .single()

        if (profile) {
          await supabase
            .from("profiles")
            .update({
              total_points: (profile.total_points || 0) + participantData.score,
            })
            .eq("id", participantData.user_id)
        }
      }
    } catch (error: any) {
      setError(error.message)
    } finally {
      setIsLoading(false)
    }
  }

  const correctAnswers = answers.filter((a) => a.is_correct).length
  const accuracy = answers.length > 0 ? (correctAnswers / answers.length) * 100 : 0
  const averageResponseTime =
    answers.length > 0 ? answers.reduce((sum, a) => sum + a.response_time, 0) / answers.length / 1000 : 0

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="w-8 h-8 text-yellow-500" />
      case 2:
        return <Medal className="w-8 h-8 text-gray-400" />
      case 3:
        return <Award className="w-8 h-8 text-amber-600" />
      default:
        return <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center font-bold">{rank}</div>
    }
  }

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1:
        return "from-yellow-500 to-yellow-600"
      case 2:
        return "from-gray-400 to-gray-500"
      case 3:
        return "from-amber-600 to-amber-700"
      default:
        return "from-primary to-secondary"
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading results...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 via-background to-secondary/5 p-4">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="text-destructive">Error</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">{error}</p>
            <Button asChild>
              <Link href="/">Go Home</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h1 className="text-xl font-bold">{session?.quizzes.title}</h1>
              <Badge variant="outline">Results</Badge>
            </div>
            <Button asChild variant="outline">
              <Link href="/">
                <Home className="w-4 h-4 mr-2" />
                Home
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Results Header */}
          <Card className="mb-8">
            <CardContent className="pt-8">
              <div className="text-center space-y-4">
                <div className="flex items-center justify-center gap-4">
                  {getRankIcon(userRank)}
                  <div>
                    <h2 className="text-3xl font-bold bg-gradient-to-r {getRankColor(userRank)} bg-clip-text text-transparent">
                      {userRank === 1 ? "🎉 Champion!" : userRank <= 3 ? "🏆 Great Job!" : "👏 Well Done!"}
                    </h2>
                    <p className="text-muted-foreground">
                      You ranked #{userRank} out of {leaderboard.length} participants
                    </p>
                  </div>
                </div>
                <div className="text-4xl font-bold">{participant?.score || 0} points</div>
              </div>
            </CardContent>
          </Card>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Performance Stats */}
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Your Performance</CardTitle>
                  <CardDescription>Detailed breakdown of your quiz performance</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground mb-2">
                        <Target className="w-4 h-4" />
                        Accuracy
                      </div>
                      <div className="text-2xl font-bold text-accent">{accuracy.toFixed(1)}%</div>
                      <Progress value={accuracy} className="mt-2" />
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground mb-2">
                        <Users className="w-4 h-4" />
                        Correct
                      </div>
                      <div className="text-2xl font-bold text-primary">
                        {correctAnswers}/{answers.length}
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground mb-2">
                        <Zap className="w-4 h-4" />
                        Best Streak
                      </div>
                      <div className="text-2xl font-bold text-secondary">{participant?.best_streak || 0}</div>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground mb-2">
                        <Trophy className="w-4 h-4" />
                        Avg Time
                      </div>
                      <div className="text-2xl font-bold">{averageResponseTime.toFixed(1)}s</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Question Breakdown */}
              <Card>
                <CardHeader>
                  <CardTitle>Question Breakdown</CardTitle>
                  <CardDescription>Review your answers</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {answers.map((answer, index) => (
                      <div
                        key={answer.id}
                        className={`p-4 rounded-lg border ${
                          answer.is_correct ? "border-accent bg-accent/5" : "border-destructive bg-destructive/5"
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <span className="text-sm font-medium">Question {index + 1}</span>
                              {answer.is_correct ? (
                                <Badge variant="default" className="bg-accent">
                                  +{answer.points_earned} pts
                                </Badge>
                              ) : (
                                <Badge variant="destructive">0 pts</Badge>
                              )}
                            </div>
                            <p className="text-sm mb-2">{answer.questions.question_text}</p>
                            <div className="text-xs text-muted-foreground">
                              Correct answer: {answer.questions.correct_answer} • Response time:{" "}
                              {(answer.response_time / 1000).toFixed(1)}s
                            </div>
                          </div>
                          <div className="ml-4">
                            {answer.is_correct ? (
                              <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center">
                                <Trophy className="w-4 h-4 text-accent-foreground" />
                              </div>
                            ) : (
                              <div className="w-8 h-8 rounded-full bg-destructive flex items-center justify-center">
                                <span className="text-destructive-foreground text-xs">✗</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Leaderboard */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Final Leaderboard</CardTitle>
                  <CardDescription>{leaderboard.length} participants</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {leaderboard.slice(0, 10).map((p, index) => (
                      <div
                        key={p.id}
                        className={`flex items-center justify-between p-3 rounded-lg ${
                          p.id === params.participantId
                            ? "bg-primary/10 border border-primary"
                            : index === 0
                              ? "bg-yellow-500/10 border border-yellow-500"
                              : index === 1
                                ? "bg-gray-400/10 border border-gray-400"
                                : index === 2
                                  ? "bg-amber-600/10 border border-amber-600"
                                  : "bg-muted"
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">
                            {index === 0 ? (
                              <Trophy className="w-5 h-5 text-yellow-500" />
                            ) : index === 1 ? (
                              <Medal className="w-5 h-5 text-gray-400" />
                            ) : index === 2 ? (
                              <Award className="w-5 h-5 text-amber-600" />
                            ) : (
                              index + 1
                            )}
                          </div>
                          <div>
                            <div className="font-medium">{p.nickname}</div>
                            {p.best_streak > 0 && (
                              <div className="text-xs text-muted-foreground">{p.best_streak} streak</div>
                            )}
                          </div>
                        </div>
                        <div className="font-bold">{p.score}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Action Buttons */}
              <div className="mt-6 space-y-3">
                <Button asChild className="w-full">
                  <Link href="/leaderboards">View Global Leaderboards</Link>
                </Button>
                <Button asChild variant="outline" className="w-full bg-transparent">
                  <Link href="/dashboard">Back to Dashboard</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
