"use client"

import { useI18n } from "@/lib/i18n/context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Plus, Play, Users, BarChart3, Settings } from "lucide-react"

interface DashboardClientProps {
  quizzes: any[]
  profile: any
}

export function DashboardClient({ quizzes, profile }: DashboardClientProps) {
  const { t } = useI18n()

  return (
    <>
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t("quizzes")}</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{quizzes?.length || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Plays</CardTitle>
            <Play className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {quizzes?.reduce((sum, quiz) => sum + (quiz.plays_count || 0), 0) || 0}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Points</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{profile?.total_points || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Badges</CardTitle>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{profile?.badges?.length || 0}</div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="flex flex-col sm:flex-row gap-4 mb-8">
        <Button asChild size="lg" className="flex-1">
          <Link href="/quiz/create">
            <Plus className="w-5 h-5 mr-2" />
            {t("create")} {t("quiz")}
          </Link>
        </Button>
        <Button asChild variant="outline" size="lg" className="flex-1 bg-transparent">
          <Link href="/community">
            <BarChart3 className="w-5 h-5 mr-2" />
            Browse Library
          </Link>
        </Button>
      </div>

      {/* Recent Quizzes */}
      <Card>
        <CardHeader>
          <CardTitle>Your {t("quizzes")}</CardTitle>
          <CardDescription>Manage and track your quiz creations</CardDescription>
        </CardHeader>
        <CardContent>
          {quizzes && quizzes.length > 0 ? (
            <div className="grid gap-4">
              {quizzes.map((quiz) => (
                <div
                  key={quiz.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="flex-1">
                    <h3 className="font-semibold">{quiz.title}</h3>
                    <p className="text-sm text-muted-foreground">{quiz.description}</p>
                    <div className="flex items-center gap-4 mt-2">
                      <Badge variant={quiz.is_public ? "default" : "secondary"}>
                        {quiz.is_public ? "Public" : "Private"}
                      </Badge>
                      <Badge variant="outline">{quiz.category}</Badge>
                      <Badge variant="outline">{quiz.difficulty}</Badge>
                      <span className="text-xs text-muted-foreground">
                        {quiz.total_questions} {t("questions")} • {quiz.plays_count} plays
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button asChild variant="outline" size="sm">
                      <Link href={`/quiz/${quiz.id}`}>View</Link>
                    </Button>
                    <Button asChild size="sm">
                      <Link href={`/quiz/${quiz.id}/host`}>Host Live</Link>
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="mx-auto w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
                <Plus className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-2">No {t("quizzes")} yet</h3>
              <p className="text-muted-foreground mb-4">
                {t("create")} your first {t("quiz")} to get started
              </p>
              <Button asChild>
                <Link href="/quiz/create">
                  {t("create")} {t("quiz")}
                </Link>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </>
  )
}
