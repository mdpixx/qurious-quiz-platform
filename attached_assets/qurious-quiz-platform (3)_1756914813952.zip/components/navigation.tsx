"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import { LogOut, User, Search, Bell } from "lucide-react"
import { LanguageSwitcher } from "@/components/language-switcher"
import { useI18n } from "@/lib/i18n/context"
import { Input } from "@/components/ui/input"

interface NavigationProps {
  userDisplayName?: string
  onSignOut?: () => void
}

export function Navigation({ userDisplayName, onSignOut }: NavigationProps) {
  const { t } = useI18n()

  return (
    <header className="bg-black/95 backdrop-blur-md border-b border-gray-800 sticky top-0 z-50">
      <div className="container mx-auto px-6 py-3">
        <div className="flex items-center justify-between">
          {/* Left section - Logo and main navigation */}
          <div className="flex items-center gap-8">
            <Link href="/" className="flex-shrink-0">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-orange-500 to-blue-600 bg-clip-text text-transparent">
                Qurious
              </h1>
            </Link>

            {/* Main navigation tabs - Netflix style */}
            <nav className="hidden lg:flex items-center gap-6">
              <Link href="/" className="text-white hover:text-gray-300 transition-colors text-sm font-medium py-2">
                {t("home")}
              </Link>
              <Link
                href="/dashboard"
                className="text-white hover:text-gray-300 transition-colors text-sm font-medium py-2"
              >
                {t("dashboard")}
              </Link>
              <Link
                href="/community"
                className="text-white hover:text-gray-300 transition-colors text-sm font-medium py-2"
              >
                {t("community")}
              </Link>
              <Link
                href="/leaderboards"
                className="text-white hover:text-gray-300 transition-colors text-sm font-medium py-2"
              >
                {t("leaderboards")}
              </Link>
              <Link
                href="/pricing"
                className="text-white hover:text-gray-300 transition-colors text-sm font-medium py-2"
              >
                {t("pricing")}
              </Link>
            </nav>
          </div>

          {/* Center section - Search bar */}
          <div className="hidden md:flex items-center flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder={t("searchQuizzes")}
                className="pl-10 bg-gray-800/50 border-gray-700 text-white placeholder-gray-400 focus:border-orange-500"
              />
            </div>
          </div>

          {/* Right section - User actions */}
          <div className="flex items-center gap-4">
            <LanguageSwitcher />

            {/* Notifications */}
            <Button variant="ghost" size="sm" className="text-white hover:text-gray-300 hover:bg-gray-800">
              <Bell className="w-4 h-4" />
            </Button>

            {/* User menu */}
            <div className="flex items-center gap-3">
              {userDisplayName && <span className="text-sm text-gray-300 hidden sm:inline">{userDisplayName}</span>}

              <Button variant="ghost" size="sm" asChild className="text-white hover:text-gray-300 hover:bg-gray-800">
                <Link href="/profile">
                  <User className="w-4 h-4" />
                </Link>
              </Button>

              {onSignOut && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onSignOut}
                  className="text-white hover:text-gray-300 hover:bg-gray-800"
                >
                  <LogOut className="w-4 h-4" />
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Mobile navigation */}
        <nav className="lg:hidden mt-4 flex items-center gap-4 overflow-x-auto pb-2">
          <Link
            href="/"
            className="text-white hover:text-gray-300 transition-colors text-sm font-medium whitespace-nowrap"
          >
            {t("home")}
          </Link>
          <Link
            href="/dashboard"
            className="text-white hover:text-gray-300 transition-colors text-sm font-medium whitespace-nowrap"
          >
            {t("dashboard")}
          </Link>
          <Link
            href="/community"
            className="text-white hover:text-gray-300 transition-colors text-sm font-medium whitespace-nowrap"
          >
            {t("community")}
          </Link>
          <Link
            href="/leaderboards"
            className="text-white hover:text-gray-300 transition-colors text-sm font-medium whitespace-nowrap"
          >
            {t("leaderboards")}
          </Link>
          <Link
            href="/pricing"
            className="text-white hover:text-gray-300 transition-colors text-sm font-medium whitespace-nowrap"
          >
            {t("pricing")}
          </Link>
        </nav>
      </div>
    </header>
  )
}
