-- Create users profiles table
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT UNIQUE NOT NULL,
  display_name TEXT NOT NULL,
  avatar_url TEXT,
  bio TEXT,
  total_points INTEGER DEFAULT 0,
  badges JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create quizzes table
CREATE TABLE IF NOT EXISTS public.quizzes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  creator_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  is_public BOOLEAN DEFAULT true,
  is_live BOOLEAN DEFAULT false,
  language TEXT DEFAULT 'en',
  difficulty TEXT CHECK (difficulty IN ('easy', 'medium', 'hard')) DEFAULT 'medium',
  category TEXT,
  time_limit INTEGER, -- seconds per question
  total_questions INTEGER DEFAULT 0,
  total_plays INTEGER DEFAULT 0,
  average_score DECIMAL(5,2) DEFAULT 0,
  thumbnail_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create questions table
CREATE TABLE IF NOT EXISTS public.questions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  quiz_id UUID NOT NULL REFERENCES public.quizzes(id) ON DELETE CASCADE,
  question_text TEXT NOT NULL,
  question_type TEXT CHECK (question_type IN ('multiple_choice', 'true_false', 'short_answer', 'poll')) DEFAULT 'multiple_choice',
  options JSONB, -- Array of options for multiple choice
  correct_answer TEXT, -- For multiple choice and true/false
  points INTEGER DEFAULT 10,
  time_limit INTEGER, -- Override quiz time limit for specific questions
  order_index INTEGER NOT NULL,
  media_url TEXT, -- For images/videos in questions
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create quiz sessions table (for live quizzes)
CREATE TABLE IF NOT EXISTS public.quiz_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  quiz_id UUID NOT NULL REFERENCES public.quizzes(id) ON DELETE CASCADE,
  host_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  session_code TEXT UNIQUE NOT NULL,
  status TEXT CHECK (status IN ('waiting', 'active', 'paused', 'completed')) DEFAULT 'waiting',
  current_question_index INTEGER DEFAULT 0,
  started_at TIMESTAMP WITH TIME ZONE,
  ended_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create participants table
CREATE TABLE IF NOT EXISTS public.participants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID NOT NULL REFERENCES public.quiz_sessions(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  nickname TEXT NOT NULL,
  score INTEGER DEFAULT 0,
  current_streak INTEGER DEFAULT 0,
  best_streak INTEGER DEFAULT 0,
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  is_active BOOLEAN DEFAULT true
);

-- Create answers table
CREATE TABLE IF NOT EXISTS public.answers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  participant_id UUID NOT NULL REFERENCES public.participants(id) ON DELETE CASCADE,
  question_id UUID NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
  answer TEXT NOT NULL,
  is_correct BOOLEAN DEFAULT false,
  points_earned INTEGER DEFAULT 0,
  response_time INTEGER, -- milliseconds
  answered_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create quiz likes table
CREATE TABLE IF NOT EXISTS public.quiz_likes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  quiz_id UUID NOT NULL REFERENCES public.quizzes(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(quiz_id, user_id)
);

-- Create user follows table
CREATE TABLE IF NOT EXISTS public.user_follows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  following_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(follower_id, following_id),
  CHECK (follower_id != following_id)
);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quizzes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.answers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_follows ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for profiles
CREATE POLICY "Users can view all profiles" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- Create RLS policies for quizzes
CREATE POLICY "Users can view public quizzes" ON public.quizzes FOR SELECT USING (is_public = true OR creator_id = auth.uid());
CREATE POLICY "Users can create quizzes" ON public.quizzes FOR INSERT WITH CHECK (auth.uid() = creator_id);
CREATE POLICY "Users can update own quizzes" ON public.quizzes FOR UPDATE USING (auth.uid() = creator_id);
CREATE POLICY "Users can delete own quizzes" ON public.quizzes FOR DELETE USING (auth.uid() = creator_id);

-- Create RLS policies for questions
CREATE POLICY "Users can view questions of accessible quizzes" ON public.questions FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.quizzes 
    WHERE quizzes.id = questions.quiz_id 
    AND (quizzes.is_public = true OR quizzes.creator_id = auth.uid())
  )
);
CREATE POLICY "Users can manage questions of own quizzes" ON public.questions FOR ALL USING (
  EXISTS (
    SELECT 1 FROM public.quizzes 
    WHERE quizzes.id = questions.quiz_id 
    AND quizzes.creator_id = auth.uid()
  )
);

-- Create RLS policies for quiz sessions
CREATE POLICY "Users can view quiz sessions they participate in" ON public.quiz_sessions FOR SELECT USING (
  host_id = auth.uid() OR 
  EXISTS (SELECT 1 FROM public.participants WHERE participants.session_id = quiz_sessions.id AND participants.user_id = auth.uid())
);
CREATE POLICY "Users can create quiz sessions for own quizzes" ON public.quiz_sessions FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM public.quizzes WHERE quizzes.id = quiz_id AND quizzes.creator_id = auth.uid())
);
CREATE POLICY "Hosts can update own quiz sessions" ON public.quiz_sessions FOR UPDATE USING (auth.uid() = host_id);

-- Create RLS policies for participants
CREATE POLICY "Users can view participants in sessions they're part of" ON public.participants FOR SELECT USING (
  user_id = auth.uid() OR 
  EXISTS (SELECT 1 FROM public.quiz_sessions WHERE quiz_sessions.id = participants.session_id AND quiz_sessions.host_id = auth.uid())
);
CREATE POLICY "Users can join quiz sessions" ON public.participants FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own participation" ON public.participants FOR UPDATE USING (auth.uid() = user_id);

-- Create RLS policies for answers
CREATE POLICY "Users can view own answers" ON public.answers FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.participants WHERE participants.id = answers.participant_id AND participants.user_id = auth.uid())
);
CREATE POLICY "Users can submit own answers" ON public.answers FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM public.participants WHERE participants.id = participant_id AND participants.user_id = auth.uid())
);

-- Create RLS policies for quiz likes
CREATE POLICY "Users can view all quiz likes" ON public.quiz_likes FOR SELECT USING (true);
CREATE POLICY "Users can manage own quiz likes" ON public.quiz_likes FOR ALL USING (auth.uid() = user_id);

-- Create RLS policies for user follows
CREATE POLICY "Users can view all follows" ON public.user_follows FOR SELECT USING (true);
CREATE POLICY "Users can manage own follows" ON public.user_follows FOR ALL USING (auth.uid() = follower_id);

-- Create indexes for better performance
CREATE INDEX idx_quizzes_creator_id ON public.quizzes(creator_id);
CREATE INDEX idx_quizzes_is_public ON public.quizzes(is_public);
CREATE INDEX idx_questions_quiz_id ON public.questions(quiz_id);
CREATE INDEX idx_questions_order_index ON public.questions(quiz_id, order_index);
CREATE INDEX idx_quiz_sessions_session_code ON public.quiz_sessions(session_code);
CREATE INDEX idx_participants_session_id ON public.participants(session_id);
CREATE INDEX idx_participants_user_id ON public.participants(user_id);
CREATE INDEX idx_answers_participant_id ON public.answers(participant_id);
CREATE INDEX idx_quiz_likes_quiz_id ON public.quiz_likes(quiz_id);
CREATE INDEX idx_user_follows_follower_id ON public.user_follows(follower_id);
CREATE INDEX idx_user_follows_following_id ON public.user_follows(following_id);
