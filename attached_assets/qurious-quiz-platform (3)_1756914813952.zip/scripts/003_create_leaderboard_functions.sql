-- Function to get weekly leaderboard
CREATE OR REPLACE FUNCTION get_weekly_leaderboard(since_date timestamp with time zone)
RETURNS TABLE (
  id uuid,
  username text,
  display_name text,
  avatar_url text,
  total_points bigint,
  badges jsonb
)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.username,
    p.display_name,
    p.avatar_url,
    COALESCE(SUM(a.points_earned), 0) as total_points,
    p.badges
  FROM profiles p
  LEFT JOIN participants pt ON pt.user_id = p.id
  LEFT JOIN answers a ON a.participant_id = pt.id AND a.answered_at >= since_date
  GROUP BY p.id, p.username, p.display_name, p.avatar_url, p.badges
  HAVING COALESCE(SUM(a.points_earned), 0) > 0
  ORDER BY total_points DESC
  LIMIT 50;
END;
$$;

-- Function to update quiz statistics
CREATE OR REPLACE FUNCTION update_quiz_stats()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  -- Update total plays and average score for the quiz
  UPDATE quizzes 
  SET 
    total_plays = (
      SELECT COUNT(DISTINCT session_id) 
      FROM participants 
      WHERE session_id IN (
        SELECT id FROM quiz_sessions WHERE quiz_id = NEW.quiz_id
      )
    ),
    average_score = (
      SELECT COALESCE(AVG(score), 0)
      FROM participants 
      WHERE session_id IN (
        SELECT id FROM quiz_sessions WHERE quiz_id = NEW.quiz_id
      )
    )
  WHERE id = NEW.quiz_id;
  
  RETURN NEW;
END;
$$;

-- Trigger to update quiz stats when a session ends
CREATE OR REPLACE TRIGGER update_quiz_stats_trigger
  AFTER UPDATE OF status ON quiz_sessions
  FOR EACH ROW
  WHEN (NEW.status = 'completed')
  EXECUTE FUNCTION update_quiz_stats();

-- Function to award badges based on achievements
CREATE OR REPLACE FUNCTION award_badges()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  user_badges jsonb;
  new_badges jsonb := '[]'::jsonb;
BEGIN
  -- Only process if user_id exists
  IF NEW.user_id IS NULL THEN
    RETURN NEW;
  END IF;

  -- Get current badges
  SELECT badges INTO user_badges FROM profiles WHERE id = NEW.user_id;
  IF user_badges IS NULL THEN
    user_badges := '[]'::jsonb;
  END IF;

  -- Check for "First Win" badge
  IF NEW.score > 0 AND NOT (user_badges ? 'first_win') THEN
    new_badges := new_badges || '["first_win"]'::jsonb;
  END IF;

  -- Check for "Perfect Score" badge (100% accuracy)
  IF NEW.score > 0 THEN
    DECLARE
      total_questions int;
      correct_answers int;
    BEGIN
      SELECT COUNT(*) INTO total_questions
      FROM answers a
      JOIN participants p ON p.id = a.participant_id
      WHERE p.id = NEW.id;
      
      SELECT COUNT(*) INTO correct_answers
      FROM answers a
      JOIN participants p ON p.id = a.participant_id
      WHERE p.id = NEW.id AND a.is_correct = true;
      
      IF total_questions > 0 AND correct_answers = total_questions AND NOT (user_badges ? 'perfect_score') THEN
        new_badges := new_badges || '["perfect_score"]'::jsonb;
      END IF;
    END;
  END IF;

  -- Check for "Speed Demon" badge (average response time < 3 seconds)
  IF NEW.score > 0 THEN
    DECLARE
      avg_response_time numeric;
    BEGIN
      SELECT AVG(response_time) INTO avg_response_time
      FROM answers a
      JOIN participants p ON p.id = a.participant_id
      WHERE p.id = NEW.id;
      
      IF avg_response_time < 3000 AND NOT (user_badges ? 'speed_demon') THEN
        new_badges := new_badges || '["speed_demon"]'::jsonb;
      END IF;
    END;
  END IF;

  -- Check for "Streak Master" badge (streak of 5 or more)
  IF NEW.best_streak >= 5 AND NOT (user_badges ? 'streak_master') THEN
    new_badges := new_badges || '["streak_master"]'::jsonb;
  END IF;

  -- Update badges if any new ones were earned
  IF jsonb_array_length(new_badges) > 0 THEN
    UPDATE profiles 
    SET badges = user_badges || new_badges
    WHERE id = NEW.user_id;
  END IF;

  RETURN NEW;
END;
$$;

-- Trigger to award badges when participant stats are updated
CREATE OR REPLACE TRIGGER award_badges_trigger
  AFTER UPDATE ON participants
  FOR EACH ROW
  EXECUTE FUNCTION award_badges();

-- Create indexes for better leaderboard performance
CREATE INDEX IF NOT EXISTS idx_profiles_total_points ON profiles(total_points DESC);
CREATE INDEX IF NOT EXISTS idx_participants_score ON participants(score DESC);
CREATE INDEX IF NOT EXISTS idx_answers_answered_at ON answers(answered_at);
CREATE INDEX IF NOT EXISTS idx_quiz_sessions_quiz_id_status ON quiz_sessions(quiz_id, status);
