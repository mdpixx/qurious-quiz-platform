-- Create subscription plans table
CREATE TABLE IF NOT EXISTS public.subscription_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  price_monthly DECIMAL(10,2) NOT NULL,
  price_yearly DECIMAL(10,2) NOT NULL,
  features JSONB NOT NULL DEFAULT '[]'::jsonb,
  max_quizzes INTEGER,
  max_participants_per_quiz INTEGER,
  max_questions_per_quiz INTEGER,
  custom_branding BOOLEAN DEFAULT false,
  advanced_analytics BOOLEAN DEFAULT false,
  priority_support BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create user subscriptions table
CREATE TABLE IF NOT EXISTS public.user_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_id UUID NOT NULL REFERENCES public.subscription_plans(id),
  status TEXT CHECK (status IN ('active', 'cancelled', 'expired', 'pending')) DEFAULT 'pending',
  billing_cycle TEXT CHECK (billing_cycle IN ('monthly', 'yearly')) NOT NULL,
  amount_paid DECIMAL(10,2) NOT NULL,
  currency TEXT DEFAULT 'INR',
  started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  cancelled_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create payments table
CREATE TABLE IF NOT EXISTS public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  subscription_id UUID REFERENCES public.user_subscriptions(id),
  payment_gateway TEXT NOT NULL, -- 'razorpay', 'payu', etc.
  gateway_payment_id TEXT NOT NULL,
  gateway_order_id TEXT,
  amount DECIMAL(10,2) NOT NULL,
  currency TEXT DEFAULT 'INR',
  status TEXT CHECK (status IN ('pending', 'completed', 'failed', 'refunded')) DEFAULT 'pending',
  payment_method TEXT, -- 'upi', 'card', 'netbanking', 'wallet'
  upi_id TEXT, -- For UPI payments
  failure_reason TEXT,
  gateway_response JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.subscription_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

-- RLS policies for subscription_plans (public read)
CREATE POLICY "Anyone can view active subscription plans" ON public.subscription_plans FOR SELECT USING (is_active = true);

-- RLS policies for user_subscriptions
CREATE POLICY "Users can view own subscriptions" ON public.user_subscriptions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own subscriptions" ON public.user_subscriptions FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own subscriptions" ON public.user_subscriptions FOR UPDATE USING (auth.uid() = user_id);

-- RLS policies for payments
CREATE POLICY "Users can view own payments" ON public.payments FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own payments" ON public.payments FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Insert default subscription plans
INSERT INTO public.subscription_plans (name, description, price_monthly, price_yearly, features, max_quizzes, max_participants_per_quiz, max_questions_per_quiz, custom_branding, advanced_analytics, priority_support) VALUES
('Free', 'Perfect for getting started', 0.00, 0.00, '["Up to 3 quizzes", "Up to 50 participants per quiz", "Up to 20 questions per quiz", "Basic analytics", "Community support"]'::jsonb, 3, 50, 20, false, false, false),
('Pro', 'Great for educators and small teams', 299.00, 2999.00, '["Unlimited quizzes", "Up to 200 participants per quiz", "Up to 100 questions per quiz", "Advanced analytics", "Custom branding", "Priority support", "Export results"]'::jsonb, NULL, 200, 100, true, true, true),
('Enterprise', 'Perfect for large organizations', 999.00, 9999.00, '["Unlimited everything", "Unlimited participants", "Unlimited questions", "Advanced analytics", "Custom branding", "Priority support", "API access", "White-label solution", "Dedicated account manager"]'::jsonb, NULL, NULL, NULL, true, true, true);

-- Create indexes
CREATE INDEX idx_user_subscriptions_user_id ON public.user_subscriptions(user_id);
CREATE INDEX idx_user_subscriptions_status ON public.user_subscriptions(status);
CREATE INDEX idx_user_subscriptions_expires_at ON public.user_subscriptions(expires_at);
CREATE INDEX idx_payments_user_id ON public.payments(user_id);
CREATE INDEX idx_payments_status ON public.payments(status);
CREATE INDEX idx_payments_gateway_payment_id ON public.payments(gateway_payment_id);

-- Function to check user subscription limits
CREATE OR REPLACE FUNCTION check_user_limits(user_uuid UUID)
RETURNS TABLE (
  plan_name TEXT,
  max_quizzes INTEGER,
  max_participants_per_quiz INTEGER,
  max_questions_per_quiz INTEGER,
  current_quizzes BIGINT,
  can_create_quiz BOOLEAN,
  has_custom_branding BOOLEAN,
  has_advanced_analytics BOOLEAN
)
LANGUAGE plpgsql
AS $$
DECLARE
  active_subscription RECORD;
  quiz_count BIGINT;
BEGIN
  -- Get active subscription
  SELECT us.*, sp.* INTO active_subscription
  FROM user_subscriptions us
  JOIN subscription_plans sp ON sp.id = us.plan_id
  WHERE us.user_id = user_uuid 
    AND us.status = 'active' 
    AND us.expires_at > NOW()
  ORDER BY us.created_at DESC
  LIMIT 1;
  
  -- If no active subscription, use free plan
  IF active_subscription IS NULL THEN
    SELECT * INTO active_subscription
    FROM subscription_plans
    WHERE name = 'Free'
    LIMIT 1;
  END IF;
  
  -- Count current quizzes
  SELECT COUNT(*) INTO quiz_count
  FROM quizzes
  WHERE creator_id = user_uuid;
  
  RETURN QUERY SELECT
    active_subscription.name,
    active_subscription.max_quizzes,
    active_subscription.max_participants_per_quiz,
    active_subscription.max_questions_per_quiz,
    quiz_count,
    (active_subscription.max_quizzes IS NULL OR quiz_count < active_subscription.max_quizzes),
    active_subscription.custom_branding,
    active_subscription.advanced_analytics;
END;
$$;
