-- Add language support to existing tables
ALTER TABLE profiles ADD COLUMN preferred_language VARCHAR(10) DEFAULT 'en';

-- Add multilingual support to quizzes
ALTER TABLE quizzes ADD COLUMN language VARCHAR(10) DEFAULT 'en';

-- Create translations table for quiz content
CREATE TABLE quiz_translations (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  quiz_id UUID REFERENCES quizzes(id) ON DELETE CASCADE,
  language VARCHAR(10) NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  UNIQUE(quiz_id, language)
);

-- Create translations table for questions
CREATE TABLE question_translations (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  question_id UUID REFERENCES questions(id) ON DELETE CASCADE,
  language VARCHAR(10) NOT NULL,
  question_text TEXT NOT NULL,
  options JSONB,
  explanation TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  UNIQUE(question_id, language)
);

-- Enable RLS
ALTER TABLE quiz_translations ENABLE ROW LEVEL SECURITY;
ALTER TABLE question_translations ENABLE ROW LEVEL SECURITY;

-- RLS policies for quiz_translations
CREATE POLICY "Quiz translations are viewable by everyone" ON quiz_translations
  FOR SELECT USING (true);

CREATE POLICY "Users can insert quiz translations for their own quizzes" ON quiz_translations
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM quizzes 
      WHERE quizzes.id = quiz_translations.quiz_id 
      AND quizzes.creator_id = auth.uid()
    )
  );

CREATE POLICY "Users can update quiz translations for their own quizzes" ON quiz_translations
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM quizzes 
      WHERE quizzes.id = quiz_translations.quiz_id 
      AND quizzes.creator_id = auth.uid()
    )
  );

-- RLS policies for question_translations
CREATE POLICY "Question translations are viewable by everyone" ON question_translations
  FOR SELECT USING (true);

CREATE POLICY "Users can insert question translations for their own questions" ON question_translations
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM questions 
      JOIN quizzes ON questions.quiz_id = quizzes.id
      WHERE questions.id = question_translations.question_id 
      AND quizzes.creator_id = auth.uid()
    )
  );

CREATE POLICY "Users can update question translations for their own questions" ON question_translations
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM questions 
      JOIN quizzes ON questions.quiz_id = quizzes.id
      WHERE questions.id = question_translations.question_id 
      AND quizzes.creator_id = auth.uid()
    )
  );

-- Create indexes for better performance
CREATE INDEX idx_quiz_translations_quiz_language ON quiz_translations(quiz_id, language);
CREATE INDEX idx_question_translations_question_language ON question_translations(question_id, language);
CREATE INDEX idx_profiles_preferred_language ON profiles(preferred_language);
CREATE INDEX idx_quizzes_language ON quizzes(language);
