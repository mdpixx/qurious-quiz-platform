-- Fix infinite recursion in RLS policies by completely rewriting them
-- This script drops all existing policies and creates simple, non-recursive ones

-- Drop all existing policies that might cause recursion
DROP POLICY IF EXISTS "Users can view their own quiz sessions" ON public.quiz_sessions;
DROP POLICY IF EXISTS "Sessions are viewable by host and participants" ON public.quiz_sessions;
DROP POLICY IF EXISTS "Hosts can manage their sessions" ON public.quiz_sessions;
DROP POLICY IF EXISTS "Users can create quiz sessions" ON public.quiz_sessions;
DROP POLICY IF EXISTS "Users can update their own sessions" ON public.quiz_sessions;
DROP POLICY IF EXISTS "Users can delete their own sessions" ON public.quiz_sessions;

DROP POLICY IF EXISTS "Users can view session participants" ON public.participants;
DROP POLICY IF EXISTS "Participants can view session participants" ON public.participants;
DROP POLICY IF EXISTS "Users can join sessions as participants" ON public.participants;
DROP POLICY IF EXISTS "Users can update their own participation" ON public.participants;
DROP POLICY IF EXISTS "Hosts can manage session participants" ON public.participants;

-- Create simple, non-recursive policies for quiz_sessions
CREATE POLICY "quiz_sessions_select_policy" ON public.quiz_sessions FOR SELECT USING (
  -- Host can see their own sessions, everyone can see public sessions
  host_id = auth.uid() OR 
  (status = 'active' AND session_code IS NOT NULL)
);

CREATE POLICY "quiz_sessions_insert_policy" ON public.quiz_sessions FOR INSERT WITH CHECK (
  -- Only authenticated users can create sessions and must be the host
  auth.uid() IS NOT NULL AND host_id = auth.uid()
);

CREATE POLICY "quiz_sessions_update_policy" ON public.quiz_sessions FOR UPDATE USING (
  -- Only the host can update their own sessions
  host_id = auth.uid()
) WITH CHECK (
  host_id = auth.uid()
);

CREATE POLICY "quiz_sessions_delete_policy" ON public.quiz_sessions FOR DELETE USING (
  -- Only the host can delete their own sessions
  host_id = auth.uid()
);

-- Create simple, non-recursive policies for participants
CREATE POLICY "participants_select_policy" ON public.participants FOR SELECT USING (
  -- Users can see their own participation or if they're the session host
  user_id = auth.uid() OR 
  EXISTS (SELECT 1 FROM public.quiz_sessions WHERE id = session_id AND host_id = auth.uid())
);

CREATE POLICY "participants_insert_policy" ON public.participants FOR INSERT WITH CHECK (
  -- Users can only create participation records for themselves
  auth.uid() IS NOT NULL AND user_id = auth.uid()
);

CREATE POLICY "participants_update_policy" ON public.participants FOR UPDATE USING (
  -- Users can update their own participation or session host can update
  user_id = auth.uid() OR 
  EXISTS (SELECT 1 FROM public.quiz_sessions WHERE id = session_id AND host_id = auth.uid())
) WITH CHECK (
  user_id = auth.uid() OR 
  EXISTS (SELECT 1 FROM public.quiz_sessions WHERE id = session_id AND host_id = auth.uid())
);

CREATE POLICY "participants_delete_policy" ON public.participants FOR DELETE USING (
  -- Users can delete their own participation or session host can delete
  user_id = auth.uid() OR 
  EXISTS (SELECT 1 FROM public.quiz_sessions WHERE id = session_id AND host_id = auth.uid())
);

-- Ensure RLS is enabled on both tables
ALTER TABLE public.quiz_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.participants ENABLE ROW LEVEL SECURITY;
