-- Fix infinite recursion in RLS policies by removing circular dependencies
-- This script drops the problematic policies and creates new non-recursive ones

-- Drop existing problematic policies
DROP POLICY IF EXISTS "Sessions are viewable by host and participants" ON public.quiz_sessions;
DROP POLICY IF EXISTS "Participants can view session participants" ON public.participants;
DROP POLICY IF EXISTS "Hosts can manage their sessions" ON public.quiz_sessions;
DROP POLICY IF EXISTS "Users can join sessions" ON public.participants;
DROP POLICY IF EXISTS "Users can update their participation" ON public.participants;

-- Create new non-recursive policies for quiz_sessions
-- Simple policy that only checks host_id directly without referencing participants table
CREATE POLICY "quiz_sessions_select_policy" ON public.quiz_sessions FOR SELECT USING (
  host_id = auth.uid()
);

-- Allow hosts to insert their own sessions
CREATE POLICY "quiz_sessions_insert_policy" ON public.quiz_sessions FOR INSERT WITH CHECK (
  host_id = auth.uid()
);

-- Allow hosts to update their own sessions
CREATE POLICY "quiz_sessions_update_policy" ON public.quiz_sessions FOR UPDATE USING (
  host_id = auth.uid()
);

-- Allow hosts to delete their own sessions
CREATE POLICY "quiz_sessions_delete_policy" ON public.quiz_sessions FOR DELETE USING (
  host_id = auth.uid()
);

-- Create new non-recursive policies for participants
-- Simple policy that only checks user_id directly without referencing quiz_sessions table
CREATE POLICY "participants_select_policy" ON public.participants FOR SELECT USING (
  user_id = auth.uid()
);

-- Allow users to insert their own participation records
CREATE POLICY "participants_insert_policy" ON public.participants FOR INSERT WITH CHECK (
  user_id = auth.uid()
);

-- Allow users to update their own participation records
CREATE POLICY "participants_update_policy" ON public.participants FOR UPDATE USING (
  user_id = auth.uid()
);

-- Allow users to delete their own participation records
CREATE POLICY "participants_delete_policy" ON public.participants FOR DELETE USING (
  user_id = auth.uid()
);

-- Create a separate policy for hosts to view participants in their sessions
-- This policy allows hosts to view participants but uses a direct join without recursion
CREATE POLICY "hosts_can_view_session_participants" ON public.participants FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.quizzes q 
    JOIN public.quiz_sessions qs ON q.id = qs.quiz_id 
    WHERE qs.id = session_id AND q.creator_id = auth.uid()
  )
);
