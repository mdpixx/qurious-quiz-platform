-- Fix infinite recursion in RLS policies for quiz_sessions and participants

-- Drop existing problematic policies
DROP POLICY IF EXISTS "Sessions are viewable by host and participants" ON public.quiz_sessions;
DROP POLICY IF EXISTS "Participants can view session participants" ON public.participants;

-- Create simplified, non-recursive policies for quiz_sessions
CREATE POLICY "Sessions are viewable by host" ON public.quiz_sessions FOR SELECT USING (host_id = auth.uid());
CREATE POLICY "Sessions are viewable by authenticated users for joining" ON public.quiz_sessions FOR SELECT USING (auth.role() = 'authenticated');

-- Create simplified policies for participants
CREATE POLICY "Participants can view all session participants" ON public.participants FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Session hosts can view all participants in their sessions" ON public.participants FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.quiz_sessions WHERE id = session_id AND host_id = auth.uid())
);

-- Ensure other policies remain intact but fix any potential recursion
-- Update participants policies to be more direct
DROP POLICY IF EXISTS "Users can join sessions" ON public.participants;
DROP POLICY IF EXISTS "Users can update their participation" ON public.participants;

CREATE POLICY "Users can join sessions" ON public.participants FOR INSERT WITH CHECK (
  auth.uid() = user_id AND 
  EXISTS (SELECT 1 FROM public.quiz_sessions WHERE id = session_id AND status IN ('waiting', 'active'))
);

CREATE POLICY "Users can update their own participation" ON public.participants FOR UPDATE USING (
  auth.uid() = user_id
);

-- Update answers policies to be more direct
DROP POLICY IF EXISTS "Users can view their own answers" ON public.answers;
DROP POLICY IF EXISTS "Users can submit their own answers" ON public.answers;

CREATE POLICY "Users can view answers in sessions they participate in" ON public.answers FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.participants WHERE id = participant_id AND user_id = auth.uid())
);

CREATE POLICY "Users can submit answers for their participation" ON public.answers FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM public.participants WHERE id = participant_id AND user_id = auth.uid())
);
