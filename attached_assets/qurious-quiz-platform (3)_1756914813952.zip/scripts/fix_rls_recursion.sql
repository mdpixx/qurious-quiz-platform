-- Fix infinite recursion in RLS policies by removing circular dependencies

-- Drop existing problematic policies
DROP POLICY IF EXISTS "Sessions are viewable by host and participants" ON public.quiz_sessions;
DROP POLICY IF EXISTS "Participants can view session participants" ON public.participants;
DROP POLICY IF EXISTS "Users can insert participants for sessions they can join" ON public.participants;
DROP POLICY IF EXISTS "Hosts can update their sessions" ON public.quiz_sessions;
DROP POLICY IF EXISTS "Hosts can delete their sessions" ON public.quiz_sessions;

-- Create simplified, non-recursive policies for quiz_sessions
CREATE POLICY "Users can view their own hosted sessions" ON public.quiz_sessions FOR SELECT USING (
  host_id = auth.uid()
);

CREATE POLICY "Users can view active public sessions" ON public.quiz_sessions FOR SELECT USING (
  status IN ('waiting', 'active') AND 
  EXISTS (SELECT 1 FROM public.quizzes WHERE id = quiz_id AND is_public = true)
);

CREATE POLICY "Hosts can insert their own sessions" ON public.quiz_sessions FOR INSERT WITH CHECK (
  host_id = auth.uid()
);

CREATE POLICY "Hosts can update their own sessions" ON public.quiz_sessions FOR UPDATE USING (
  host_id = auth.uid()
) WITH CHECK (
  host_id = auth.uid()
);

CREATE POLICY "Hosts can delete their own sessions" ON public.quiz_sessions FOR DELETE USING (
  host_id = auth.uid()
);

-- Create simplified, non-recursive policies for participants
CREATE POLICY "Users can view participants in sessions they host" ON public.participants FOR SELECT USING (
  user_id = auth.uid() OR 
  EXISTS (SELECT 1 FROM public.quiz_sessions WHERE id = session_id AND host_id = auth.uid())
);

CREATE POLICY "Users can insert themselves as participants" ON public.participants FOR INSERT WITH CHECK (
  user_id = auth.uid()
);

CREATE POLICY "Users can update their own participation" ON public.participants FOR UPDATE USING (
  user_id = auth.uid()
) WITH CHECK (
  user_id = auth.uid()
);

CREATE POLICY "Users can delete their own participation" ON public.participants FOR DELETE USING (
  user_id = auth.uid()
);

-- Create policy for hosts to manage participants in their sessions
CREATE POLICY "Hosts can manage participants in their sessions" ON public.participants FOR ALL USING (
  EXISTS (SELECT 1 FROM public.quiz_sessions WHERE id = session_id AND host_id = auth.uid())
) WITH CHECK (
  EXISTS (SELECT 1 FROM public.quiz_sessions WHERE id = session_id AND host_id = auth.uid())
);
